# Generated from /app/at_krl.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,58,462,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        1,0,1,0,1,0,1,0,1,1,4,1,86,8,1,11,1,12,1,87,1,2,4,2,91,8,2,11,2,
        12,2,92,1,3,4,3,96,8,3,11,3,12,3,97,1,4,1,4,4,4,102,8,4,11,4,12,
        4,103,1,5,1,5,1,6,1,6,1,6,1,6,1,6,3,6,113,8,6,1,6,1,6,1,6,1,6,1,
        6,3,6,120,8,6,3,6,122,8,6,1,7,1,7,1,7,1,7,1,7,3,7,129,8,7,1,7,3,
        7,132,8,7,1,8,1,8,4,8,136,8,8,11,8,12,8,137,1,9,1,9,1,9,1,10,1,10,
        4,10,145,8,10,11,10,12,10,146,1,11,1,11,1,11,1,11,1,11,1,11,1,11,
        1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,3,13,164,8,13,1,14,1,14,
        1,14,1,14,1,14,1,14,3,14,172,8,14,1,14,1,14,1,14,1,14,1,14,3,14,
        179,8,14,1,14,1,14,1,14,1,14,1,14,3,14,186,8,14,1,14,1,14,1,14,1,
        14,1,14,3,14,193,8,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,14,1,
        14,1,14,3,14,205,8,14,1,14,3,14,208,8,14,1,14,1,14,1,14,1,14,1,14,
        3,14,215,8,14,1,14,1,14,1,14,1,14,1,14,3,14,222,8,14,1,14,1,14,1,
        14,1,14,1,14,3,14,229,8,14,1,14,1,14,1,14,1,14,1,14,3,14,236,8,14,
        5,14,238,8,14,10,14,12,14,241,9,14,1,15,1,15,1,15,1,15,1,16,1,16,
        1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,
        1,16,1,16,1,16,1,16,1,16,1,16,3,16,268,8,16,1,16,1,16,1,16,1,16,
        1,16,3,16,275,8,16,1,16,1,16,1,16,1,16,1,16,3,16,282,8,16,1,16,1,
        16,1,16,1,16,1,16,3,16,289,8,16,1,16,1,16,1,16,1,16,1,16,3,16,296,
        8,16,5,16,298,8,16,10,16,12,16,301,9,16,1,17,1,17,1,18,1,18,1,19,
        1,19,1,19,1,19,1,19,1,19,3,19,313,8,19,1,20,1,20,1,20,3,20,318,8,
        20,1,21,1,21,1,22,1,22,1,22,1,22,3,22,326,8,22,1,22,1,22,1,22,3,
        22,331,8,22,1,23,1,23,1,24,1,24,1,24,1,24,3,24,339,8,24,1,25,3,25,
        342,8,25,1,25,1,25,1,25,3,25,347,8,25,1,26,1,26,4,26,351,8,26,11,
        26,12,26,352,1,27,1,27,1,27,1,27,1,27,1,27,1,28,1,28,1,28,4,28,364,
        8,28,11,28,12,28,365,1,29,1,29,1,29,1,30,1,30,1,30,1,30,3,30,375,
        8,30,1,30,3,30,378,8,30,1,31,1,31,1,31,1,31,1,32,1,32,1,32,1,32,
        5,32,388,8,32,10,32,12,32,391,9,32,1,32,3,32,394,8,32,1,32,1,32,
        1,33,1,33,1,33,1,33,3,33,402,8,33,1,34,1,34,1,34,3,34,407,8,34,1,
        35,1,35,1,35,3,35,412,8,35,1,35,1,35,1,35,1,35,1,35,3,35,419,8,35,
        1,36,1,36,1,36,3,36,424,8,36,1,36,1,36,1,36,1,36,1,36,1,36,1,36,
        1,36,1,36,3,36,435,8,36,1,37,1,37,3,37,439,8,37,1,37,1,37,1,38,3,
        38,444,8,38,1,38,4,38,447,8,38,11,38,12,38,448,1,39,1,39,1,39,1,
        39,1,39,1,39,3,39,457,8,39,1,39,3,39,460,8,39,1,39,8,87,92,97,103,
        352,365,389,448,2,28,32,40,0,2,4,6,8,10,12,14,16,18,20,22,24,26,
        28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,60,62,64,66,68,70,
        72,74,76,78,0,9,1,0,1,3,1,0,53,54,2,0,52,52,55,55,1,0,5,6,1,0,7,
        10,1,0,8,10,3,0,52,52,55,55,58,58,1,0,28,29,1,0,26,27,495,0,80,1,
        0,0,0,2,85,1,0,0,0,4,90,1,0,0,0,6,95,1,0,0,0,8,99,1,0,0,0,10,105,
        1,0,0,0,12,121,1,0,0,0,14,123,1,0,0,0,16,133,1,0,0,0,18,139,1,0,
        0,0,20,142,1,0,0,0,22,148,1,0,0,0,24,155,1,0,0,0,26,163,1,0,0,0,
        28,207,1,0,0,0,30,242,1,0,0,0,32,267,1,0,0,0,34,302,1,0,0,0,36,304,
        1,0,0,0,38,312,1,0,0,0,40,314,1,0,0,0,42,319,1,0,0,0,44,330,1,0,
        0,0,46,332,1,0,0,0,48,334,1,0,0,0,50,346,1,0,0,0,52,348,1,0,0,0,
        54,354,1,0,0,0,56,360,1,0,0,0,58,367,1,0,0,0,60,370,1,0,0,0,62,379,
        1,0,0,0,64,383,1,0,0,0,66,397,1,0,0,0,68,406,1,0,0,0,70,408,1,0,
        0,0,72,420,1,0,0,0,74,438,1,0,0,0,76,443,1,0,0,0,78,450,1,0,0,0,
        80,81,3,2,1,0,81,82,3,4,2,0,82,83,3,6,3,0,83,1,1,0,0,0,84,86,3,48,
        24,0,85,84,1,0,0,0,86,87,1,0,0,0,87,88,1,0,0,0,87,85,1,0,0,0,88,
        3,1,0,0,0,89,91,3,66,33,0,90,89,1,0,0,0,91,92,1,0,0,0,92,93,1,0,
        0,0,92,90,1,0,0,0,93,5,1,0,0,0,94,96,3,14,7,0,95,94,1,0,0,0,96,97,
        1,0,0,0,97,98,1,0,0,0,97,95,1,0,0,0,98,7,1,0,0,0,99,101,5,24,0,0,
        100,102,9,0,0,0,101,100,1,0,0,0,102,103,1,0,0,0,103,104,1,0,0,0,
        103,101,1,0,0,0,104,9,1,0,0,0,105,106,3,12,6,0,106,11,1,0,0,0,107,
        108,3,40,20,0,108,109,7,0,0,0,109,112,3,46,23,0,110,113,3,26,13,
        0,111,113,1,0,0,0,112,110,1,0,0,0,112,111,1,0,0,0,113,122,1,0,0,
        0,114,115,3,46,23,0,115,116,5,4,0,0,116,119,3,40,20,0,117,120,3,
        26,13,0,118,120,1,0,0,0,119,117,1,0,0,0,119,118,1,0,0,0,120,122,
        1,0,0,0,121,107,1,0,0,0,121,114,1,0,0,0,122,13,1,0,0,0,123,124,5,
        15,0,0,124,125,7,1,0,0,125,126,3,18,9,0,126,128,3,16,8,0,127,129,
        3,20,10,0,128,127,1,0,0,0,128,129,1,0,0,0,129,131,1,0,0,0,130,132,
        3,8,4,0,131,130,1,0,0,0,131,132,1,0,0,0,132,15,1,0,0,0,133,135,5,
        17,0,0,134,136,3,10,5,0,135,134,1,0,0,0,136,137,1,0,0,0,137,135,
        1,0,0,0,137,138,1,0,0,0,138,17,1,0,0,0,139,140,5,16,0,0,140,141,
        3,28,14,0,141,19,1,0,0,0,142,144,5,18,0,0,143,145,3,10,5,0,144,143,
        1,0,0,0,145,146,1,0,0,0,146,144,1,0,0,0,146,147,1,0,0,0,147,21,1,
        0,0,0,148,149,5,13,0,0,149,150,5,47,0,0,150,151,7,2,0,0,151,152,
        7,3,0,0,152,153,7,2,0,0,153,154,5,48,0,0,154,23,1,0,0,0,155,156,
        5,14,0,0,156,157,7,2,0,0,157,25,1,0,0,0,158,159,3,22,11,0,159,160,
        3,24,12,0,160,164,1,0,0,0,161,164,3,22,11,0,162,164,3,24,12,0,163,
        158,1,0,0,0,163,161,1,0,0,0,163,162,1,0,0,0,164,27,1,0,0,0,165,166,
        6,14,-1,0,166,167,3,40,20,0,167,168,5,1,0,0,168,171,3,38,19,0,169,
        172,3,26,13,0,170,172,1,0,0,0,171,169,1,0,0,0,171,170,1,0,0,0,172,
        208,1,0,0,0,173,174,3,38,19,0,174,175,5,1,0,0,175,178,3,40,20,0,
        176,179,3,26,13,0,177,179,1,0,0,0,178,176,1,0,0,0,178,177,1,0,0,
        0,179,208,1,0,0,0,180,181,3,40,20,0,181,182,5,1,0,0,182,185,3,40,
        20,0,183,186,3,26,13,0,184,186,1,0,0,0,185,183,1,0,0,0,185,184,1,
        0,0,0,186,208,1,0,0,0,187,188,3,38,19,0,188,189,5,1,0,0,189,192,
        3,38,19,0,190,193,3,26,13,0,191,193,1,0,0,0,192,190,1,0,0,0,192,
        191,1,0,0,0,193,208,1,0,0,0,194,208,3,44,22,0,195,208,3,38,19,0,
        196,197,5,45,0,0,197,198,3,28,14,0,198,199,5,46,0,0,199,208,1,0,
        0,0,200,201,7,4,0,0,201,204,3,28,14,0,202,205,3,26,13,0,203,205,
        1,0,0,0,204,202,1,0,0,0,204,203,1,0,0,0,205,208,1,0,0,0,206,208,
        3,30,15,0,207,165,1,0,0,0,207,173,1,0,0,0,207,180,1,0,0,0,207,187,
        1,0,0,0,207,194,1,0,0,0,207,195,1,0,0,0,207,196,1,0,0,0,207,200,
        1,0,0,0,207,206,1,0,0,0,208,239,1,0,0,0,209,210,10,7,0,0,210,211,
        5,42,0,0,211,214,3,28,14,0,212,215,3,26,13,0,213,215,1,0,0,0,214,
        212,1,0,0,0,214,213,1,0,0,0,215,238,1,0,0,0,216,217,10,6,0,0,217,
        218,5,41,0,0,218,221,3,28,14,0,219,222,3,26,13,0,220,222,1,0,0,0,
        221,219,1,0,0,0,221,220,1,0,0,0,222,238,1,0,0,0,223,224,10,5,0,0,
        224,225,5,40,0,0,225,228,3,28,14,0,226,229,3,26,13,0,227,229,1,0,
        0,0,228,226,1,0,0,0,228,227,1,0,0,0,229,238,1,0,0,0,230,231,10,4,
        0,0,231,232,5,39,0,0,232,235,3,28,14,0,233,236,3,26,13,0,234,236,
        1,0,0,0,235,233,1,0,0,0,235,234,1,0,0,0,236,238,1,0,0,0,237,209,
        1,0,0,0,237,216,1,0,0,0,237,223,1,0,0,0,237,230,1,0,0,0,238,241,
        1,0,0,0,239,237,1,0,0,0,239,240,1,0,0,0,240,29,1,0,0,0,241,239,1,
        0,0,0,242,243,7,1,0,0,243,244,5,43,0,0,244,245,7,1,0,0,245,31,1,
        0,0,0,246,247,6,16,-1,0,247,248,3,36,18,0,248,249,5,1,0,0,249,250,
        3,40,20,0,250,268,1,0,0,0,251,252,3,40,20,0,252,253,5,1,0,0,253,
        254,3,40,20,0,254,268,1,0,0,0,255,256,3,40,20,0,256,257,5,1,0,0,
        257,258,3,36,18,0,258,268,1,0,0,0,259,268,3,42,21,0,260,268,3,36,
        18,0,261,262,5,45,0,0,262,263,3,32,16,0,263,264,5,46,0,0,264,268,
        1,0,0,0,265,266,7,5,0,0,266,268,3,32,16,1,267,246,1,0,0,0,267,251,
        1,0,0,0,267,255,1,0,0,0,267,259,1,0,0,0,267,260,1,0,0,0,267,261,
        1,0,0,0,267,265,1,0,0,0,268,299,1,0,0,0,269,270,10,6,0,0,270,271,
        5,42,0,0,271,274,3,32,16,0,272,275,3,26,13,0,273,275,1,0,0,0,274,
        272,1,0,0,0,274,273,1,0,0,0,275,298,1,0,0,0,276,277,10,5,0,0,277,
        278,5,41,0,0,278,281,3,32,16,0,279,282,3,26,13,0,280,282,1,0,0,0,
        281,279,1,0,0,0,281,280,1,0,0,0,282,298,1,0,0,0,283,284,10,4,0,0,
        284,285,5,40,0,0,285,288,3,32,16,0,286,289,3,26,13,0,287,289,1,0,
        0,0,288,286,1,0,0,0,288,287,1,0,0,0,289,298,1,0,0,0,290,291,10,3,
        0,0,291,292,5,39,0,0,292,295,3,32,16,0,293,296,3,26,13,0,294,296,
        1,0,0,0,295,293,1,0,0,0,295,294,1,0,0,0,296,298,1,0,0,0,297,269,
        1,0,0,0,297,276,1,0,0,0,297,283,1,0,0,0,297,290,1,0,0,0,298,301,
        1,0,0,0,299,297,1,0,0,0,299,300,1,0,0,0,300,33,1,0,0,0,301,299,1,
        0,0,0,302,303,3,32,16,0,303,35,1,0,0,0,304,305,7,6,0,0,305,37,1,
        0,0,0,306,307,5,45,0,0,307,308,3,38,19,0,308,309,3,26,13,0,309,310,
        5,46,0,0,310,313,1,0,0,0,311,313,3,36,18,0,312,306,1,0,0,0,312,311,
        1,0,0,0,313,39,1,0,0,0,314,317,7,1,0,0,315,316,5,44,0,0,316,318,
        3,40,20,0,317,315,1,0,0,0,317,318,1,0,0,0,318,41,1,0,0,0,319,320,
        3,40,20,0,320,43,1,0,0,0,321,322,5,45,0,0,322,325,3,42,21,0,323,
        326,3,26,13,0,324,326,1,0,0,0,325,323,1,0,0,0,325,324,1,0,0,0,326,
        327,1,0,0,0,327,328,5,46,0,0,328,331,1,0,0,0,329,331,3,42,21,0,330,
        321,1,0,0,0,330,329,1,0,0,0,331,45,1,0,0,0,332,333,3,28,14,0,333,
        47,1,0,0,0,334,335,5,19,0,0,335,336,7,1,0,0,336,338,3,50,25,0,337,
        339,3,8,4,0,338,337,1,0,0,0,338,339,1,0,0,0,339,49,1,0,0,0,340,342,
        3,52,26,0,341,340,1,0,0,0,341,342,1,0,0,0,342,343,1,0,0,0,343,347,
        3,56,28,0,344,347,3,52,26,0,345,347,3,54,27,0,346,341,1,0,0,0,346,
        344,1,0,0,0,346,345,1,0,0,0,347,51,1,0,0,0,348,350,5,34,0,0,349,
        351,5,58,0,0,350,349,1,0,0,0,351,352,1,0,0,0,352,353,1,0,0,0,352,
        350,1,0,0,0,353,53,1,0,0,0,354,355,5,35,0,0,355,356,5,37,0,0,356,
        357,7,2,0,0,357,358,5,38,0,0,358,359,7,2,0,0,359,55,1,0,0,0,360,
        361,5,36,0,0,361,363,5,52,0,0,362,364,3,58,29,0,363,362,1,0,0,0,
        364,365,1,0,0,0,365,366,1,0,0,0,365,363,1,0,0,0,366,57,1,0,0,0,367,
        368,3,60,30,0,368,369,3,64,32,0,369,59,1,0,0,0,370,371,5,58,0,0,
        371,372,7,2,0,0,372,374,7,2,0,0,373,375,5,52,0,0,374,373,1,0,0,0,
        374,375,1,0,0,0,375,377,1,0,0,0,376,378,5,1,0,0,377,376,1,0,0,0,
        377,378,1,0,0,0,378,61,1,0,0,0,379,380,7,2,0,0,380,381,5,11,0,0,
        381,382,7,2,0,0,382,63,1,0,0,0,383,384,5,49,0,0,384,389,3,62,31,
        0,385,386,7,3,0,0,386,388,3,62,31,0,387,385,1,0,0,0,388,391,1,0,
        0,0,389,390,1,0,0,0,389,387,1,0,0,0,390,393,1,0,0,0,391,389,1,0,
        0,0,392,394,7,3,0,0,393,392,1,0,0,0,393,394,1,0,0,0,394,395,1,0,
        0,0,395,396,5,50,0,0,396,65,1,0,0,0,397,398,5,20,0,0,398,399,7,1,
        0,0,399,401,3,68,34,0,400,402,3,8,4,0,401,400,1,0,0,0,401,402,1,
        0,0,0,402,67,1,0,0,0,403,407,3,70,35,0,404,407,3,72,36,0,405,407,
        3,74,37,0,406,403,1,0,0,0,406,404,1,0,0,0,406,405,1,0,0,0,407,69,
        1,0,0,0,408,409,5,21,0,0,409,411,7,7,0,0,410,412,5,23,0,0,411,410,
        1,0,0,0,411,412,1,0,0,0,412,413,1,0,0,0,413,414,5,30,0,0,414,415,
        5,33,0,0,415,416,5,25,0,0,416,418,3,34,17,0,417,419,3,8,4,0,418,
        417,1,0,0,0,418,419,1,0,0,0,419,71,1,0,0,0,420,421,5,21,0,0,421,
        423,7,8,0,0,422,424,5,23,0,0,423,422,1,0,0,0,423,424,1,0,0,0,424,
        425,1,0,0,0,425,426,5,31,0,0,426,427,5,33,0,0,427,428,5,25,0,0,428,
        429,3,34,17,0,429,430,5,32,0,0,430,431,5,33,0,0,431,432,5,25,0,0,
        432,434,3,34,17,0,433,435,3,8,4,0,434,433,1,0,0,0,434,435,1,0,0,
        0,435,73,1,0,0,0,436,437,5,21,0,0,437,439,7,1,0,0,438,436,1,0,0,
        0,438,439,1,0,0,0,439,440,1,0,0,0,440,441,3,76,38,0,441,75,1,0,0,
        0,442,444,5,23,0,0,443,442,1,0,0,0,443,444,1,0,0,0,444,446,1,0,0,
        0,445,447,3,78,39,0,446,445,1,0,0,0,447,448,1,0,0,0,448,449,1,0,
        0,0,448,446,1,0,0,0,449,77,1,0,0,0,450,451,5,22,0,0,451,452,7,1,
        0,0,452,453,5,19,0,0,453,456,7,1,0,0,454,455,5,25,0,0,455,457,3,
        46,23,0,456,454,1,0,0,0,456,457,1,0,0,0,457,459,1,0,0,0,458,460,
        3,8,4,0,459,458,1,0,0,0,459,460,1,0,0,0,460,79,1,0,0,0,55,87,92,
        97,103,112,119,121,128,131,137,146,163,171,178,185,192,204,207,214,
        221,228,235,237,239,267,274,281,288,295,297,299,312,317,325,330,
        338,341,346,352,365,374,377,389,393,401,406,411,418,423,434,438,
        443,448,456,459
    ]

class at_krlParser ( Parser ):

    grammarFileName = "at_krl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "':='", "'<-'", "'->'", "';'", 
                     "','", "'-'", "'~'", "'!'", "'not'", "'|'", "'\\r\\n'", 
                     "'\\u0423\\u0412\\u0415\\u0420\\u0415\\u041D\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u0422\\u041E\\u0427\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u041F\\u0420\\u0410\\u0412\\u0418\\u041B\\u041E'", 
                     "'\\u0415\\u0421\\u041B\\u0418'", "'\\u0422\\u041E'", 
                     "'\\u0418\\u041D\\u0410\\u0427\\u0415'", "'\\u0422\\u0418\\u041F'", 
                     "'\\u041E\\u0411\\u042A\\u0415\\u041A\\u0422'", "'\\u0413\\u0420\\u0423\\u041F\\u041F\\u0410'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422\\u042B'", 
                     "'\\u041A\\u041E\\u041C\\u041C\\u0415\\u041D\\u0422\\u0410\\u0420\\u0418\\u0419'", 
                     "'\\u0417\\u041D\\u0410\\u0427\\u0415\\u041D\\u0418\\u0415'", 
                     "'\\u0418\\u041D\\u0422\\u0415\\u0420\\u0412\\u0410\\u041B'", 
                     "'\\u0418\\u043D\\u0442\\u0435\\u0440\\u0432\\u0430\\u043B'", 
                     "'\\u0421\\u041E\\u0411\\u042B\\u0422\\u0418\\u0415'", 
                     "'\\u0421\\u043E\\u0431\\u044B\\u0442\\u0438\\u0435'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u0412\\u043E\\u0437\\u043D'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041D\\u0430\\u0447'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041E\\u043A\\u043E\\u043D\\u0447'", 
                     "'\\u0422\\u0418\\u041F \\u041B\\u043E\\u0433\\u0412\\u044B\\u0440'", 
                     "'\\u0421\\u0418\\u041C\\u0412\\u041E\\u041B'", "'\\u0427\\u0418\\u0421\\u041B\\u041E'", 
                     "'\\u041D\\u0415\\u0427\\u0415\\u0422\\u041A\\u0418\\u0419'", 
                     "'\\u041E\\u0422'", "'\\u0414\\u041E'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'.'", "'('", "')'", "'['", "']'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "NEW_LINE", "BELIEF", "ACCURACY", "RULE", "IF", "THEN", 
                      "ELSE", "TYPE", "OBJECT", "GROUP", "ATTR", "ATTRS", 
                      "COMMENT", "VALUE", "INTERVAL", "CASED_INTERVAL", 
                      "EVENT", "CASED_EVENT", "OCCURANCE_CONDITION", "OPEN", 
                      "CLOSE", "SIMPLE_EXP_TYPE", "SYM", "NUM", "FUZ", "FROM", 
                      "TO", "LOG_SIGN", "COMP_SIGN", "LOWP_MATH_SIGN", "HIGHP_MATH_SIGN", 
                      "ALLEN_SIGN", "DOT", "L_BR", "R_BR", "LS_BR", "RS_BR", 
                      "LF_BR", "RF_BR", "LETTER", "NUMERIC", "ALPHANUMERIC", 
                      "ALPHANUMERIC_U", "FRAC", "WS", "COMM_CHAR", "STRING" ]

    RULE_knowledge_base = 0
    RULE_kb_types = 1
    RULE_kb_classes = 2
    RULE_kb_rules = 3
    RULE_commentary = 4
    RULE_instructions = 5
    RULE_assign_instruction = 6
    RULE_kb_rule = 7
    RULE_kb_rule_instructions = 8
    RULE_kb_rule_condition = 9
    RULE_kb_rule_else_instructions = 10
    RULE_belief = 11
    RULE_accuracy = 12
    RULE_non_factor = 13
    RULE_kb_operation = 14
    RULE_kb_allen_operation = 15
    RULE_simple_operation = 16
    RULE_simple_evaluatable = 17
    RULE_simple_value = 18
    RULE_kb_value = 19
    RULE_ref_path = 20
    RULE_simple_ref = 21
    RULE_kb_reference = 22
    RULE_evaluatable = 23
    RULE_kb_type = 24
    RULE_kb_type_body = 25
    RULE_symbolic_type_body = 26
    RULE_numeric_type_body = 27
    RULE_fuzzy_type_body = 28
    RULE_membersip_function = 29
    RULE_mf_def = 30
    RULE_mf_point = 31
    RULE_mf_body = 32
    RULE_kb_class = 33
    RULE_kb_class_body = 34
    RULE_event_body = 35
    RULE_interval_body = 36
    RULE_object_body = 37
    RULE_attributes = 38
    RULE_attribute = 39

    ruleNames =  [ "knowledge_base", "kb_types", "kb_classes", "kb_rules", 
                   "commentary", "instructions", "assign_instruction", "kb_rule", 
                   "kb_rule_instructions", "kb_rule_condition", "kb_rule_else_instructions", 
                   "belief", "accuracy", "non_factor", "kb_operation", "kb_allen_operation", 
                   "simple_operation", "simple_evaluatable", "simple_value", 
                   "kb_value", "ref_path", "simple_ref", "kb_reference", 
                   "evaluatable", "kb_type", "kb_type_body", "symbolic_type_body", 
                   "numeric_type_body", "fuzzy_type_body", "membersip_function", 
                   "mf_def", "mf_point", "mf_body", "kb_class", "kb_class_body", 
                   "event_body", "interval_body", "object_body", "attributes", 
                   "attribute" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    NEW_LINE=12
    BELIEF=13
    ACCURACY=14
    RULE=15
    IF=16
    THEN=17
    ELSE=18
    TYPE=19
    OBJECT=20
    GROUP=21
    ATTR=22
    ATTRS=23
    COMMENT=24
    VALUE=25
    INTERVAL=26
    CASED_INTERVAL=27
    EVENT=28
    CASED_EVENT=29
    OCCURANCE_CONDITION=30
    OPEN=31
    CLOSE=32
    SIMPLE_EXP_TYPE=33
    SYM=34
    NUM=35
    FUZ=36
    FROM=37
    TO=38
    LOG_SIGN=39
    COMP_SIGN=40
    LOWP_MATH_SIGN=41
    HIGHP_MATH_SIGN=42
    ALLEN_SIGN=43
    DOT=44
    L_BR=45
    R_BR=46
    LS_BR=47
    RS_BR=48
    LF_BR=49
    RF_BR=50
    LETTER=51
    NUMERIC=52
    ALPHANUMERIC=53
    ALPHANUMERIC_U=54
    FRAC=55
    WS=56
    COMM_CHAR=57
    STRING=58

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Knowledge_baseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_types(self):
            return self.getTypedRuleContext(at_krlParser.Kb_typesContext,0)


        def kb_classes(self):
            return self.getTypedRuleContext(at_krlParser.Kb_classesContext,0)


        def kb_rules(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rulesContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_knowledge_base

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnowledge_base" ):
                listener.enterKnowledge_base(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnowledge_base" ):
                listener.exitKnowledge_base(self)




    def knowledge_base(self):

        localctx = at_krlParser.Knowledge_baseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_knowledge_base)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.kb_types()
            self.state = 81
            self.kb_classes()
            self.state = 82
            self.kb_rules()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_type(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_typeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_typeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_types

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_types" ):
                listener.enterKb_types(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_types" ):
                listener.exitKb_types(self)




    def kb_types(self):

        localctx = at_krlParser.Kb_typesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_kb_types)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 85 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 84
                    self.kb_type()

                else:
                    raise NoViableAltException(self)
                self.state = 87 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_class(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_classContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_classContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_classes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_classes" ):
                listener.enterKb_classes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_classes" ):
                listener.exitKb_classes(self)




    def kb_classes(self):

        localctx = at_krlParser.Kb_classesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_kb_classes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 90 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 89
                    self.kb_class()

                else:
                    raise NoViableAltException(self)
                self.state = 92 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_rule(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_ruleContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_ruleContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rules" ):
                listener.enterKb_rules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rules" ):
                listener.exitKb_rules(self)




    def kb_rules(self):

        localctx = at_krlParser.Kb_rulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_kb_rules)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 94
                    self.kb_rule()

                else:
                    raise NoViableAltException(self)
                self.state = 97 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(at_krlParser.COMMENT, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_commentary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCommentary" ):
                listener.enterCommentary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCommentary" ):
                listener.exitCommentary(self)




    def commentary(self):

        localctx = at_krlParser.CommentaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_commentary)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self.match(at_krlParser.COMMENT)
            self.state = 101 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 100
                    self.matchWildcard()

                else:
                    raise NoViableAltException(self)
                self.state = 103 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign_instruction(self):
            return self.getTypedRuleContext(at_krlParser.Assign_instructionContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstructions" ):
                listener.enterInstructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstructions" ):
                listener.exitInstructions(self)




    def instructions(self):

        localctx = at_krlParser.InstructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_instructions)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 105
            self.assign_instruction()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Assign_instructionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_assign_instruction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign_instruction" ):
                listener.enterAssign_instruction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign_instruction" ):
                listener.exitAssign_instruction(self)




    def assign_instruction(self):

        localctx = at_krlParser.Assign_instructionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_assign_instruction)
        self._la = 0 # Token type
        try:
            self.state = 121
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 107
                self.ref_path()
                self.state = 108
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 109
                self.evaluatable()
                self.state = 112
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 110
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 10, 15, 18, 24, 45, 52, 53, 54, 55, 58]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 114
                self.evaluatable()
                self.state = 115
                self.match(at_krlParser.T__3)
                self.state = 116
                self.ref_path()
                self.state = 119
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 117
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 10, 15, 18, 24, 45, 52, 53, 54, 55, 58]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_ruleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RULE(self):
            return self.getToken(at_krlParser.RULE, 0)

        def kb_rule_condition(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_conditionContext,0)


        def kb_rule_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_instructionsContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def kb_rule_else_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_else_instructionsContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule" ):
                listener.enterKb_rule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule" ):
                listener.exitKb_rule(self)




    def kb_rule(self):

        localctx = at_krlParser.Kb_ruleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_kb_rule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 123
            self.match(at_krlParser.RULE)
            self.state = 124
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 125
            self.kb_rule_condition()
            self.state = 126
            self.kb_rule_instructions()
            self.state = 128
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 127
                self.kb_rule_else_instructions()


            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 130
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def THEN(self):
            return self.getToken(at_krlParser.THEN, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_instructions" ):
                listener.enterKb_rule_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_instructions" ):
                listener.exitKb_rule_instructions(self)




    def kb_rule_instructions(self):

        localctx = at_krlParser.Kb_rule_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_kb_rule_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 133
            self.match(at_krlParser.THEN)
            self.state = 135 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 134
                self.instructions()
                self.state = 137 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 355819554934359936) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_conditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(at_krlParser.IF, 0)

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_condition" ):
                listener.enterKb_rule_condition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_condition" ):
                listener.exitKb_rule_condition(self)




    def kb_rule_condition(self):

        localctx = at_krlParser.Kb_rule_conditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_kb_rule_condition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 139
            self.match(at_krlParser.IF)
            self.state = 140
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_else_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(at_krlParser.ELSE, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_else_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_else_instructions" ):
                listener.enterKb_rule_else_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_else_instructions" ):
                listener.exitKb_rule_else_instructions(self)




    def kb_rule_else_instructions(self):

        localctx = at_krlParser.Kb_rule_else_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_kb_rule_else_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self.match(at_krlParser.ELSE)
            self.state = 144 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 143
                self.instructions()
                self.state = 146 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 355819554934359936) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BeliefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BELIEF(self):
            return self.getToken(at_krlParser.BELIEF, 0)

        def LS_BR(self):
            return self.getToken(at_krlParser.LS_BR, 0)

        def RS_BR(self):
            return self.getToken(at_krlParser.RS_BR, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_belief

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBelief" ):
                listener.enterBelief(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBelief" ):
                listener.exitBelief(self)




    def belief(self):

        localctx = at_krlParser.BeliefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_belief)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 148
            self.match(at_krlParser.BELIEF)
            self.state = 149
            self.match(at_krlParser.LS_BR)
            self.state = 150
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 151
            _la = self._input.LA(1)
            if not(_la==5 or _la==6):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 152
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 153
            self.match(at_krlParser.RS_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AccuracyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACCURACY(self):
            return self.getToken(at_krlParser.ACCURACY, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_accuracy

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAccuracy" ):
                listener.enterAccuracy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAccuracy" ):
                listener.exitAccuracy(self)




    def accuracy(self):

        localctx = at_krlParser.AccuracyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_accuracy)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 155
            self.match(at_krlParser.ACCURACY)
            self.state = 156
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Non_factorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def belief(self):
            return self.getTypedRuleContext(at_krlParser.BeliefContext,0)


        def accuracy(self):
            return self.getTypedRuleContext(at_krlParser.AccuracyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_non_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNon_factor" ):
                listener.enterNon_factor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNon_factor" ):
                listener.exitNon_factor(self)




    def non_factor(self):

        localctx = at_krlParser.Non_factorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_non_factor)
        try:
            self.state = 163
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 158
                self.belief()
                self.state = 159
                self.accuracy()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 161
                self.belief()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 162
                self.accuracy()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def kb_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_valueContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_valueContext,i)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def kb_reference(self):
            return self.getTypedRuleContext(at_krlParser.Kb_referenceContext,0)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_operationContext,i)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def kb_allen_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_allen_operationContext,0)


        def HIGHP_MATH_SIGN(self):
            return self.getToken(at_krlParser.HIGHP_MATH_SIGN, 0)

        def LOWP_MATH_SIGN(self):
            return self.getToken(at_krlParser.LOWP_MATH_SIGN, 0)

        def COMP_SIGN(self):
            return self.getToken(at_krlParser.COMP_SIGN, 0)

        def LOG_SIGN(self):
            return self.getToken(at_krlParser.LOG_SIGN, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_kb_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_operation" ):
                listener.enterKb_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_operation" ):
                listener.exitKb_operation(self)



    def kb_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Kb_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 28
        self.enterRecursionRule(localctx, 28, self.RULE_kb_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 207
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 166
                self.ref_path()
                self.state = 167
                self.match(at_krlParser.T__0)
                self.state = 168
                self.kb_value()
                self.state = 171
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                if la_ == 1:
                    self.state = 169
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 2:
                self.state = 173
                self.kb_value()
                self.state = 174
                self.match(at_krlParser.T__0)
                self.state = 175
                self.ref_path()
                self.state = 178
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 176
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 3:
                self.state = 180
                self.ref_path()
                self.state = 181
                self.match(at_krlParser.T__0)
                self.state = 182
                self.ref_path()
                self.state = 185
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
                if la_ == 1:
                    self.state = 183
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 4:
                self.state = 187
                self.kb_value()
                self.state = 188
                self.match(at_krlParser.T__0)
                self.state = 189
                self.kb_value()
                self.state = 192
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
                if la_ == 1:
                    self.state = 190
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 5:
                self.state = 194
                self.kb_reference()
                pass

            elif la_ == 6:
                self.state = 195
                self.kb_value()
                pass

            elif la_ == 7:
                self.state = 196
                self.match(at_krlParser.L_BR)
                self.state = 197
                self.kb_operation(0)
                self.state = 198
                self.match(at_krlParser.R_BR)
                pass

            elif la_ == 8:
                self.state = 200
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1920) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 201
                self.kb_operation(0)
                self.state = 204
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
                if la_ == 1:
                    self.state = 202
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 9:
                self.state = 206
                self.kb_allen_operation()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 239
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 237
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 209
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 210
                        self.match(at_krlParser.HIGHP_MATH_SIGN)
                        self.state = 211
                        self.kb_operation(0)
                        self.state = 214
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                        if la_ == 1:
                            self.state = 212
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 216
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 217
                        self.match(at_krlParser.LOWP_MATH_SIGN)
                        self.state = 218
                        self.kb_operation(0)
                        self.state = 221
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                        if la_ == 1:
                            self.state = 219
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 223
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 224
                        self.match(at_krlParser.COMP_SIGN)
                        self.state = 225
                        self.kb_operation(0)
                        self.state = 228
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                        if la_ == 1:
                            self.state = 226
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 230
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 231
                        self.match(at_krlParser.LOG_SIGN)
                        self.state = 232
                        self.kb_operation(0)
                        self.state = 235
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                        if la_ == 1:
                            self.state = 233
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 241
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Kb_allen_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALLEN_SIGN(self):
            return self.getToken(at_krlParser.ALLEN_SIGN, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_kb_allen_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_allen_operation" ):
                listener.enterKb_allen_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_allen_operation" ):
                listener.exitKb_allen_operation(self)




    def kb_allen_operation(self):

        localctx = at_krlParser.Kb_allen_operationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_kb_allen_operation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 242
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 243
            self.match(at_krlParser.ALLEN_SIGN)
            self.state = 244
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def simple_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_operationContext,i)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def HIGHP_MATH_SIGN(self):
            return self.getToken(at_krlParser.HIGHP_MATH_SIGN, 0)

        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def LOWP_MATH_SIGN(self):
            return self.getToken(at_krlParser.LOWP_MATH_SIGN, 0)

        def COMP_SIGN(self):
            return self.getToken(at_krlParser.COMP_SIGN, 0)

        def LOG_SIGN(self):
            return self.getToken(at_krlParser.LOG_SIGN, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_simple_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_operation" ):
                listener.enterSimple_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_operation" ):
                listener.exitSimple_operation(self)



    def simple_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Simple_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 32
        self.enterRecursionRule(localctx, 32, self.RULE_simple_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 267
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 247
                self.simple_value()
                self.state = 248
                self.match(at_krlParser.T__0)
                self.state = 249
                self.ref_path()
                pass

            elif la_ == 2:
                self.state = 251
                self.ref_path()
                self.state = 252
                self.match(at_krlParser.T__0)
                self.state = 253
                self.ref_path()
                pass

            elif la_ == 3:
                self.state = 255
                self.ref_path()
                self.state = 256
                self.match(at_krlParser.T__0)
                self.state = 257
                self.simple_value()
                pass

            elif la_ == 4:
                self.state = 259
                self.simple_ref()
                pass

            elif la_ == 5:
                self.state = 260
                self.simple_value()
                pass

            elif la_ == 6:
                self.state = 261
                self.match(at_krlParser.L_BR)
                self.state = 262
                self.simple_operation(0)
                self.state = 263
                self.match(at_krlParser.R_BR)
                pass

            elif la_ == 7:
                self.state = 265
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1792) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 266
                self.simple_operation(1)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 299
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 297
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 269
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 270
                        self.match(at_krlParser.HIGHP_MATH_SIGN)
                        self.state = 271
                        self.simple_operation(0)
                        self.state = 274
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
                        if la_ == 1:
                            self.state = 272
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 276
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 277
                        self.match(at_krlParser.LOWP_MATH_SIGN)
                        self.state = 278
                        self.simple_operation(0)
                        self.state = 281
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
                        if la_ == 1:
                            self.state = 279
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 283
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 284
                        self.match(at_krlParser.COMP_SIGN)
                        self.state = 285
                        self.simple_operation(0)
                        self.state = 288
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
                        if la_ == 1:
                            self.state = 286
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 290
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 291
                        self.match(at_krlParser.LOG_SIGN)
                        self.state = 292
                        self.simple_operation(0)
                        self.state = 295
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
                        if la_ == 1:
                            self.state = 293
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 301
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Simple_evaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_operation(self):
            return self.getTypedRuleContext(at_krlParser.Simple_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_evaluatable" ):
                listener.enterSimple_evaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_evaluatable" ):
                listener.exitSimple_evaluatable(self)




    def simple_evaluatable(self):

        localctx = at_krlParser.Simple_evaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_simple_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 302
            self.simple_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_simple_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_value" ):
                listener.enterSimple_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_value" ):
                listener.exitSimple_value(self)




    def simple_value(self):

        localctx = at_krlParser.Simple_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_simple_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 304
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 328762772798046208) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_value(self):
            return self.getTypedRuleContext(at_krlParser.Kb_valueContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_value" ):
                listener.enterKb_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_value" ):
                listener.exitKb_value(self)




    def kb_value(self):

        localctx = at_krlParser.Kb_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_kb_value)
        try:
            self.state = 312
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 306
                self.match(at_krlParser.L_BR)
                self.state = 307
                self.kb_value()
                self.state = 308
                self.non_factor()
                self.state = 309
                self.match(at_krlParser.R_BR)
                pass
            elif token in [52, 55, 58]:
                self.enterOuterAlt(localctx, 2)
                self.state = 311
                self.simple_value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ref_pathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def DOT(self):
            return self.getToken(at_krlParser.DOT, 0)

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_ref_path

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRef_path" ):
                listener.enterRef_path(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRef_path" ):
                listener.exitRef_path(self)




    def ref_path(self):

        localctx = at_krlParser.Ref_pathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_ref_path)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 314
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 317
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.state = 315
                self.match(at_krlParser.DOT)
                self.state = 316
                self.ref_path()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_refContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_ref

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_ref" ):
                listener.enterSimple_ref(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_ref" ):
                listener.exitSimple_ref(self)




    def simple_ref(self):

        localctx = at_krlParser.Simple_refContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_simple_ref)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 319
            self.ref_path()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_referenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_reference" ):
                listener.enterKb_reference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_reference" ):
                listener.exitKb_reference(self)




    def kb_reference(self):

        localctx = at_krlParser.Kb_referenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_kb_reference)
        try:
            self.state = 330
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 321
                self.match(at_krlParser.L_BR)
                self.state = 322
                self.simple_ref()
                self.state = 325
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 323
                    self.non_factor()
                    pass
                elif token in [46]:
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 327
                self.match(at_krlParser.R_BR)
                pass
            elif token in [53, 54]:
                self.enterOuterAlt(localctx, 2)
                self.state = 329
                self.simple_ref()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EvaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvaluatable" ):
                listener.enterEvaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvaluatable" ):
                listener.exitEvaluatable(self)




    def evaluatable(self):

        localctx = at_krlParser.EvaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 332
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def kb_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_type_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type" ):
                listener.enterKb_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type" ):
                listener.exitKb_type(self)




    def kb_type(self):

        localctx = at_krlParser.Kb_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_kb_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 334
            self.match(at_krlParser.TYPE)
            self.state = 335
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 336
            self.kb_type_body()
            self.state = 338
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 337
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fuzzy_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Fuzzy_type_bodyContext,0)


        def symbolic_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Symbolic_type_bodyContext,0)


        def numeric_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Numeric_type_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type_body" ):
                listener.enterKb_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type_body" ):
                listener.exitKb_type_body(self)




    def kb_type_body(self):

        localctx = at_krlParser.Kb_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_kb_type_body)
        self._la = 0 # Token type
        try:
            self.state = 346
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 341
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==34:
                    self.state = 340
                    self.symbolic_type_body()


                self.state = 343
                self.fuzzy_type_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 344
                self.symbolic_type_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 345
                self.numeric_type_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Symbolic_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SYM(self):
            return self.getToken(at_krlParser.SYM, 0)

        def STRING(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.STRING)
            else:
                return self.getToken(at_krlParser.STRING, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_symbolic_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSymbolic_type_body" ):
                listener.enterSymbolic_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSymbolic_type_body" ):
                listener.exitSymbolic_type_body(self)




    def symbolic_type_body(self):

        localctx = at_krlParser.Symbolic_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_symbolic_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 348
            self.match(at_krlParser.SYM)
            self.state = 350 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 349
                    self.match(at_krlParser.STRING)

                else:
                    raise NoViableAltException(self)
                self.state = 352 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Numeric_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUM(self):
            return self.getToken(at_krlParser.NUM, 0)

        def FROM(self):
            return self.getToken(at_krlParser.FROM, 0)

        def TO(self):
            return self.getToken(at_krlParser.TO, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_numeric_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumeric_type_body" ):
                listener.enterNumeric_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumeric_type_body" ):
                listener.exitNumeric_type_body(self)




    def numeric_type_body(self):

        localctx = at_krlParser.Numeric_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_numeric_type_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 354
            self.match(at_krlParser.NUM)
            self.state = 355
            self.match(at_krlParser.FROM)
            self.state = 356
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 357
            self.match(at_krlParser.TO)
            self.state = 358
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fuzzy_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUZ(self):
            return self.getToken(at_krlParser.FUZ, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def membersip_function(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Membersip_functionContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Membersip_functionContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_fuzzy_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuzzy_type_body" ):
                listener.enterFuzzy_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuzzy_type_body" ):
                listener.exitFuzzy_type_body(self)




    def fuzzy_type_body(self):

        localctx = at_krlParser.Fuzzy_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_fuzzy_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 360
            self.match(at_krlParser.FUZ)
            self.state = 361
            self.match(at_krlParser.NUMERIC)
            self.state = 363 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 362
                    self.membersip_function()

                else:
                    raise NoViableAltException(self)
                self.state = 365 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,39,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Membersip_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mf_def(self):
            return self.getTypedRuleContext(at_krlParser.Mf_defContext,0)


        def mf_body(self):
            return self.getTypedRuleContext(at_krlParser.Mf_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_membersip_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMembersip_function" ):
                listener.enterMembersip_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMembersip_function" ):
                listener.exitMembersip_function(self)




    def membersip_function(self):

        localctx = at_krlParser.Membersip_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_membersip_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 367
            self.mf_def()
            self.state = 368
            self.mf_body()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_def" ):
                listener.enterMf_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_def" ):
                listener.exitMf_def(self)




    def mf_def(self):

        localctx = at_krlParser.Mf_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_mf_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 370
            self.match(at_krlParser.STRING)
            self.state = 371
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 372
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 374
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==52:
                self.state = 373
                self.match(at_krlParser.NUMERIC)


            self.state = 377
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 376
                self.match(at_krlParser.T__0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_pointContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_point

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_point" ):
                listener.enterMf_point(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_point" ):
                listener.exitMf_point(self)




    def mf_point(self):

        localctx = at_krlParser.Mf_pointContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_mf_point)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 379
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 380
            self.match(at_krlParser.T__10)
            self.state = 381
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LF_BR(self):
            return self.getToken(at_krlParser.LF_BR, 0)

        def RF_BR(self):
            return self.getToken(at_krlParser.RF_BR, 0)

        def mf_point(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Mf_pointContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Mf_pointContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_mf_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_body" ):
                listener.enterMf_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_body" ):
                listener.exitMf_body(self)




    def mf_body(self):

        localctx = at_krlParser.Mf_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_mf_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 383
            self.match(at_krlParser.LF_BR)

            self.state = 384
            self.mf_point()
            self.state = 389
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,42,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 385
                    _la = self._input.LA(1)
                    if not(_la==5 or _la==6):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 386
                    self.mf_point() 
                self.state = 391
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

            self.state = 393
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5 or _la==6:
                self.state = 392
                _la = self._input.LA(1)
                if not(_la==5 or _la==6):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 395
            self.match(at_krlParser.RF_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OBJECT(self):
            return self.getToken(at_krlParser.OBJECT, 0)

        def kb_class_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_class_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class" ):
                listener.enterKb_class(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class" ):
                listener.exitKb_class(self)




    def kb_class(self):

        localctx = at_krlParser.Kb_classContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_kb_class)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 397
            self.match(at_krlParser.OBJECT)
            self.state = 398
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 399
            self.kb_class_body()
            self.state = 401
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 400
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_class_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def event_body(self):
            return self.getTypedRuleContext(at_krlParser.Event_bodyContext,0)


        def interval_body(self):
            return self.getTypedRuleContext(at_krlParser.Interval_bodyContext,0)


        def object_body(self):
            return self.getTypedRuleContext(at_krlParser.Object_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class_body" ):
                listener.enterKb_class_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class_body" ):
                listener.exitKb_class_body(self)




    def kb_class_body(self):

        localctx = at_krlParser.Kb_class_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_kb_class_body)
        try:
            self.state = 406
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,45,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 403
                self.event_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 404
                self.interval_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 405
                self.object_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Event_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OCCURANCE_CONDITION(self):
            return self.getToken(at_krlParser.OCCURANCE_CONDITION, 0)

        def SIMPLE_EXP_TYPE(self):
            return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, 0)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def simple_evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,0)


        def EVENT(self):
            return self.getToken(at_krlParser.EVENT, 0)

        def CASED_EVENT(self):
            return self.getToken(at_krlParser.CASED_EVENT, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_event_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvent_body" ):
                listener.enterEvent_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvent_body" ):
                listener.exitEvent_body(self)




    def event_body(self):

        localctx = at_krlParser.Event_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_event_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 408
            self.match(at_krlParser.GROUP)
            self.state = 409
            _la = self._input.LA(1)
            if not(_la==28 or _la==29):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 411
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 410
                self.match(at_krlParser.ATTRS)


            self.state = 413
            self.match(at_krlParser.OCCURANCE_CONDITION)
            self.state = 414
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 415
            self.match(at_krlParser.VALUE)
            self.state = 416
            self.simple_evaluatable()
            self.state = 418
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 417
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Interval_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OPEN(self):
            return self.getToken(at_krlParser.OPEN, 0)

        def SIMPLE_EXP_TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.SIMPLE_EXP_TYPE)
            else:
                return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, i)

        def VALUE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.VALUE)
            else:
                return self.getToken(at_krlParser.VALUE, i)

        def simple_evaluatable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_evaluatableContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,i)


        def CLOSE(self):
            return self.getToken(at_krlParser.CLOSE, 0)

        def INTERVAL(self):
            return self.getToken(at_krlParser.INTERVAL, 0)

        def CASED_INTERVAL(self):
            return self.getToken(at_krlParser.CASED_INTERVAL, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_interval_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInterval_body" ):
                listener.enterInterval_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInterval_body" ):
                listener.exitInterval_body(self)




    def interval_body(self):

        localctx = at_krlParser.Interval_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_interval_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 420
            self.match(at_krlParser.GROUP)
            self.state = 421
            _la = self._input.LA(1)
            if not(_la==26 or _la==27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 423
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 422
                self.match(at_krlParser.ATTRS)


            self.state = 425
            self.match(at_krlParser.OPEN)
            self.state = 426
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 427
            self.match(at_krlParser.VALUE)
            self.state = 428
            self.simple_evaluatable()
            self.state = 429
            self.match(at_krlParser.CLOSE)
            self.state = 430
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 431
            self.match(at_krlParser.VALUE)
            self.state = 432
            self.simple_evaluatable()
            self.state = 434
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,49,self._ctx)
            if la_ == 1:
                self.state = 433
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Object_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def attributes(self):
            return self.getTypedRuleContext(at_krlParser.AttributesContext,0)


        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_object_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObject_body" ):
                listener.enterObject_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObject_body" ):
                listener.exitObject_body(self)




    def object_body(self):

        localctx = at_krlParser.Object_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_object_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 438
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==21:
                self.state = 436
                self.match(at_krlParser.GROUP)
                self.state = 437
                _la = self._input.LA(1)
                if not(_la==53 or _la==54):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 440
            self.attributes()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.AttributeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.AttributeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_attributes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributes" ):
                listener.enterAttributes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributes" ):
                listener.exitAttributes(self)




    def attributes(self):

        localctx = at_krlParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 443
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 442
                self.match(at_krlParser.ATTRS)


            self.state = 446 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 445
                    self.attribute()

                else:
                    raise NoViableAltException(self)
                self.state = 448 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,52,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTR(self):
            return self.getToken(at_krlParser.ATTR, 0)

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = at_krlParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_attribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 450
            self.match(at_krlParser.ATTR)
            self.state = 451
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 452
            self.match(at_krlParser.TYPE)
            self.state = 453
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 456
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25:
                self.state = 454
                self.match(at_krlParser.VALUE)
                self.state = 455
                self.evaluatable()


            self.state = 459
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
            if la_ == 1:
                self.state = 458
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[14] = self.kb_operation_sempred
        self._predicates[16] = self.simple_operation_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def kb_operation_sempred(self, localctx:Kb_operationContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 4)
         

    def simple_operation_sempred(self, localctx:Simple_operationContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 3)
         




