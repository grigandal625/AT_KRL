# Generated from /app/at_krl.g4 by ANTLR 4.13.0
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,58,465,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,2,23,7,23,2,24,7,24,2,25,7,25,2,26,7,26,
        2,27,7,27,2,28,7,28,2,29,7,29,2,30,7,30,2,31,7,31,2,32,7,32,2,33,
        7,33,2,34,7,34,2,35,7,35,2,36,7,36,2,37,7,37,2,38,7,38,2,39,7,39,
        1,0,1,0,1,0,1,0,1,1,5,1,86,8,1,10,1,12,1,89,9,1,1,2,5,2,92,8,2,10,
        2,12,2,95,9,2,1,3,5,3,98,8,3,10,3,12,3,101,9,3,1,4,1,4,4,4,105,8,
        4,11,4,12,4,106,1,5,1,5,1,6,1,6,1,6,1,6,1,6,3,6,116,8,6,1,6,1,6,
        1,6,1,6,1,6,3,6,123,8,6,3,6,125,8,6,1,7,1,7,1,7,1,7,1,7,3,7,132,
        8,7,1,7,3,7,135,8,7,1,8,1,8,4,8,139,8,8,11,8,12,8,140,1,9,1,9,1,
        9,1,10,1,10,4,10,148,8,10,11,10,12,10,149,1,11,1,11,1,11,1,11,1,
        11,1,11,1,11,1,12,1,12,1,12,1,13,1,13,1,13,1,13,1,13,3,13,167,8,
        13,1,14,1,14,1,14,1,14,1,14,1,14,3,14,175,8,14,1,14,1,14,1,14,1,
        14,1,14,3,14,182,8,14,1,14,1,14,1,14,1,14,1,14,3,14,189,8,14,1,14,
        1,14,1,14,1,14,1,14,3,14,196,8,14,1,14,1,14,1,14,1,14,1,14,1,14,
        1,14,1,14,1,14,1,14,3,14,208,8,14,1,14,3,14,211,8,14,1,14,1,14,1,
        14,1,14,1,14,3,14,218,8,14,1,14,1,14,1,14,1,14,1,14,3,14,225,8,14,
        1,14,1,14,1,14,1,14,1,14,3,14,232,8,14,1,14,1,14,1,14,1,14,1,14,
        3,14,239,8,14,5,14,241,8,14,10,14,12,14,244,9,14,1,15,1,15,1,15,
        1,15,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,
        1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,1,16,3,16,271,8,16,1,16,
        1,16,1,16,1,16,1,16,3,16,278,8,16,1,16,1,16,1,16,1,16,1,16,3,16,
        285,8,16,1,16,1,16,1,16,1,16,1,16,3,16,292,8,16,1,16,1,16,1,16,1,
        16,1,16,3,16,299,8,16,5,16,301,8,16,10,16,12,16,304,9,16,1,17,1,
        17,1,18,1,18,1,19,1,19,1,19,1,19,1,19,1,19,3,19,316,8,19,1,20,1,
        20,1,20,3,20,321,8,20,1,21,1,21,1,22,1,22,1,22,1,22,3,22,329,8,22,
        1,22,1,22,1,22,3,22,334,8,22,1,23,1,23,1,24,1,24,1,24,1,24,3,24,
        342,8,24,1,25,3,25,345,8,25,1,25,1,25,1,25,3,25,350,8,25,1,26,1,
        26,4,26,354,8,26,11,26,12,26,355,1,27,1,27,1,27,1,27,1,27,1,27,1,
        28,1,28,1,28,4,28,367,8,28,11,28,12,28,368,1,29,1,29,1,29,1,30,1,
        30,1,30,1,30,3,30,378,8,30,1,30,3,30,381,8,30,1,31,1,31,1,31,1,31,
        1,32,1,32,1,32,1,32,5,32,391,8,32,10,32,12,32,394,9,32,1,32,3,32,
        397,8,32,1,32,1,32,1,33,1,33,1,33,1,33,3,33,405,8,33,1,34,1,34,1,
        34,3,34,410,8,34,1,35,1,35,1,35,3,35,415,8,35,1,35,1,35,1,35,1,35,
        1,35,3,35,422,8,35,1,36,1,36,1,36,3,36,427,8,36,1,36,1,36,1,36,1,
        36,1,36,1,36,1,36,1,36,1,36,3,36,438,8,36,1,37,1,37,3,37,442,8,37,
        1,37,1,37,1,38,3,38,447,8,38,1,38,4,38,450,8,38,11,38,12,38,451,
        1,39,1,39,1,39,1,39,1,39,1,39,3,39,460,8,39,1,39,3,39,463,8,39,1,
        39,8,87,93,99,106,355,368,392,451,2,28,32,40,0,2,4,6,8,10,12,14,
        16,18,20,22,24,26,28,30,32,34,36,38,40,42,44,46,48,50,52,54,56,58,
        60,62,64,66,68,70,72,74,76,78,0,9,1,0,1,3,1,0,53,54,2,0,52,52,55,
        55,1,0,5,6,1,0,7,10,1,0,8,10,3,0,52,52,55,55,58,58,1,0,28,29,1,0,
        26,27,498,0,80,1,0,0,0,2,87,1,0,0,0,4,93,1,0,0,0,6,99,1,0,0,0,8,
        102,1,0,0,0,10,108,1,0,0,0,12,124,1,0,0,0,14,126,1,0,0,0,16,136,
        1,0,0,0,18,142,1,0,0,0,20,145,1,0,0,0,22,151,1,0,0,0,24,158,1,0,
        0,0,26,166,1,0,0,0,28,210,1,0,0,0,30,245,1,0,0,0,32,270,1,0,0,0,
        34,305,1,0,0,0,36,307,1,0,0,0,38,315,1,0,0,0,40,317,1,0,0,0,42,322,
        1,0,0,0,44,333,1,0,0,0,46,335,1,0,0,0,48,337,1,0,0,0,50,349,1,0,
        0,0,52,351,1,0,0,0,54,357,1,0,0,0,56,363,1,0,0,0,58,370,1,0,0,0,
        60,373,1,0,0,0,62,382,1,0,0,0,64,386,1,0,0,0,66,400,1,0,0,0,68,409,
        1,0,0,0,70,411,1,0,0,0,72,423,1,0,0,0,74,441,1,0,0,0,76,446,1,0,
        0,0,78,453,1,0,0,0,80,81,3,2,1,0,81,82,3,4,2,0,82,83,3,6,3,0,83,
        1,1,0,0,0,84,86,3,48,24,0,85,84,1,0,0,0,86,89,1,0,0,0,87,88,1,0,
        0,0,87,85,1,0,0,0,88,3,1,0,0,0,89,87,1,0,0,0,90,92,3,66,33,0,91,
        90,1,0,0,0,92,95,1,0,0,0,93,94,1,0,0,0,93,91,1,0,0,0,94,5,1,0,0,
        0,95,93,1,0,0,0,96,98,3,14,7,0,97,96,1,0,0,0,98,101,1,0,0,0,99,100,
        1,0,0,0,99,97,1,0,0,0,100,7,1,0,0,0,101,99,1,0,0,0,102,104,5,24,
        0,0,103,105,9,0,0,0,104,103,1,0,0,0,105,106,1,0,0,0,106,107,1,0,
        0,0,106,104,1,0,0,0,107,9,1,0,0,0,108,109,3,12,6,0,109,11,1,0,0,
        0,110,111,3,40,20,0,111,112,7,0,0,0,112,115,3,46,23,0,113,116,3,
        26,13,0,114,116,1,0,0,0,115,113,1,0,0,0,115,114,1,0,0,0,116,125,
        1,0,0,0,117,118,3,46,23,0,118,119,5,4,0,0,119,122,3,40,20,0,120,
        123,3,26,13,0,121,123,1,0,0,0,122,120,1,0,0,0,122,121,1,0,0,0,123,
        125,1,0,0,0,124,110,1,0,0,0,124,117,1,0,0,0,125,13,1,0,0,0,126,127,
        5,15,0,0,127,128,7,1,0,0,128,129,3,18,9,0,129,131,3,16,8,0,130,132,
        3,20,10,0,131,130,1,0,0,0,131,132,1,0,0,0,132,134,1,0,0,0,133,135,
        3,8,4,0,134,133,1,0,0,0,134,135,1,0,0,0,135,15,1,0,0,0,136,138,5,
        17,0,0,137,139,3,10,5,0,138,137,1,0,0,0,139,140,1,0,0,0,140,138,
        1,0,0,0,140,141,1,0,0,0,141,17,1,0,0,0,142,143,5,16,0,0,143,144,
        3,28,14,0,144,19,1,0,0,0,145,147,5,18,0,0,146,148,3,10,5,0,147,146,
        1,0,0,0,148,149,1,0,0,0,149,147,1,0,0,0,149,150,1,0,0,0,150,21,1,
        0,0,0,151,152,5,13,0,0,152,153,5,47,0,0,153,154,7,2,0,0,154,155,
        7,3,0,0,155,156,7,2,0,0,156,157,5,48,0,0,157,23,1,0,0,0,158,159,
        5,14,0,0,159,160,7,2,0,0,160,25,1,0,0,0,161,162,3,22,11,0,162,163,
        3,24,12,0,163,167,1,0,0,0,164,167,3,22,11,0,165,167,3,24,12,0,166,
        161,1,0,0,0,166,164,1,0,0,0,166,165,1,0,0,0,167,27,1,0,0,0,168,169,
        6,14,-1,0,169,170,3,40,20,0,170,171,5,1,0,0,171,174,3,38,19,0,172,
        175,3,26,13,0,173,175,1,0,0,0,174,172,1,0,0,0,174,173,1,0,0,0,175,
        211,1,0,0,0,176,177,3,38,19,0,177,178,5,1,0,0,178,181,3,40,20,0,
        179,182,3,26,13,0,180,182,1,0,0,0,181,179,1,0,0,0,181,180,1,0,0,
        0,182,211,1,0,0,0,183,184,3,40,20,0,184,185,5,1,0,0,185,188,3,40,
        20,0,186,189,3,26,13,0,187,189,1,0,0,0,188,186,1,0,0,0,188,187,1,
        0,0,0,189,211,1,0,0,0,190,191,3,38,19,0,191,192,5,1,0,0,192,195,
        3,38,19,0,193,196,3,26,13,0,194,196,1,0,0,0,195,193,1,0,0,0,195,
        194,1,0,0,0,196,211,1,0,0,0,197,211,3,44,22,0,198,211,3,38,19,0,
        199,200,5,45,0,0,200,201,3,28,14,0,201,202,5,46,0,0,202,211,1,0,
        0,0,203,204,7,4,0,0,204,207,3,28,14,0,205,208,3,26,13,0,206,208,
        1,0,0,0,207,205,1,0,0,0,207,206,1,0,0,0,208,211,1,0,0,0,209,211,
        3,30,15,0,210,168,1,0,0,0,210,176,1,0,0,0,210,183,1,0,0,0,210,190,
        1,0,0,0,210,197,1,0,0,0,210,198,1,0,0,0,210,199,1,0,0,0,210,203,
        1,0,0,0,210,209,1,0,0,0,211,242,1,0,0,0,212,213,10,7,0,0,213,214,
        5,42,0,0,214,217,3,28,14,0,215,218,3,26,13,0,216,218,1,0,0,0,217,
        215,1,0,0,0,217,216,1,0,0,0,218,241,1,0,0,0,219,220,10,6,0,0,220,
        221,5,41,0,0,221,224,3,28,14,0,222,225,3,26,13,0,223,225,1,0,0,0,
        224,222,1,0,0,0,224,223,1,0,0,0,225,241,1,0,0,0,226,227,10,5,0,0,
        227,228,5,40,0,0,228,231,3,28,14,0,229,232,3,26,13,0,230,232,1,0,
        0,0,231,229,1,0,0,0,231,230,1,0,0,0,232,241,1,0,0,0,233,234,10,4,
        0,0,234,235,5,39,0,0,235,238,3,28,14,0,236,239,3,26,13,0,237,239,
        1,0,0,0,238,236,1,0,0,0,238,237,1,0,0,0,239,241,1,0,0,0,240,212,
        1,0,0,0,240,219,1,0,0,0,240,226,1,0,0,0,240,233,1,0,0,0,241,244,
        1,0,0,0,242,240,1,0,0,0,242,243,1,0,0,0,243,29,1,0,0,0,244,242,1,
        0,0,0,245,246,7,1,0,0,246,247,5,43,0,0,247,248,7,1,0,0,248,31,1,
        0,0,0,249,250,6,16,-1,0,250,251,3,36,18,0,251,252,5,1,0,0,252,253,
        3,40,20,0,253,271,1,0,0,0,254,255,3,40,20,0,255,256,5,1,0,0,256,
        257,3,40,20,0,257,271,1,0,0,0,258,259,3,40,20,0,259,260,5,1,0,0,
        260,261,3,36,18,0,261,271,1,0,0,0,262,271,3,42,21,0,263,271,3,36,
        18,0,264,265,5,45,0,0,265,266,3,32,16,0,266,267,5,46,0,0,267,271,
        1,0,0,0,268,269,7,5,0,0,269,271,3,32,16,1,270,249,1,0,0,0,270,254,
        1,0,0,0,270,258,1,0,0,0,270,262,1,0,0,0,270,263,1,0,0,0,270,264,
        1,0,0,0,270,268,1,0,0,0,271,302,1,0,0,0,272,273,10,6,0,0,273,274,
        5,42,0,0,274,277,3,32,16,0,275,278,3,26,13,0,276,278,1,0,0,0,277,
        275,1,0,0,0,277,276,1,0,0,0,278,301,1,0,0,0,279,280,10,5,0,0,280,
        281,5,41,0,0,281,284,3,32,16,0,282,285,3,26,13,0,283,285,1,0,0,0,
        284,282,1,0,0,0,284,283,1,0,0,0,285,301,1,0,0,0,286,287,10,4,0,0,
        287,288,5,40,0,0,288,291,3,32,16,0,289,292,3,26,13,0,290,292,1,0,
        0,0,291,289,1,0,0,0,291,290,1,0,0,0,292,301,1,0,0,0,293,294,10,3,
        0,0,294,295,5,39,0,0,295,298,3,32,16,0,296,299,3,26,13,0,297,299,
        1,0,0,0,298,296,1,0,0,0,298,297,1,0,0,0,299,301,1,0,0,0,300,272,
        1,0,0,0,300,279,1,0,0,0,300,286,1,0,0,0,300,293,1,0,0,0,301,304,
        1,0,0,0,302,300,1,0,0,0,302,303,1,0,0,0,303,33,1,0,0,0,304,302,1,
        0,0,0,305,306,3,32,16,0,306,35,1,0,0,0,307,308,7,6,0,0,308,37,1,
        0,0,0,309,310,5,45,0,0,310,311,3,38,19,0,311,312,3,26,13,0,312,313,
        5,46,0,0,313,316,1,0,0,0,314,316,3,36,18,0,315,309,1,0,0,0,315,314,
        1,0,0,0,316,39,1,0,0,0,317,320,7,1,0,0,318,319,5,44,0,0,319,321,
        3,40,20,0,320,318,1,0,0,0,320,321,1,0,0,0,321,41,1,0,0,0,322,323,
        3,40,20,0,323,43,1,0,0,0,324,325,5,45,0,0,325,328,3,42,21,0,326,
        329,3,26,13,0,327,329,1,0,0,0,328,326,1,0,0,0,328,327,1,0,0,0,329,
        330,1,0,0,0,330,331,5,46,0,0,331,334,1,0,0,0,332,334,3,42,21,0,333,
        324,1,0,0,0,333,332,1,0,0,0,334,45,1,0,0,0,335,336,3,28,14,0,336,
        47,1,0,0,0,337,338,5,19,0,0,338,339,7,1,0,0,339,341,3,50,25,0,340,
        342,3,8,4,0,341,340,1,0,0,0,341,342,1,0,0,0,342,49,1,0,0,0,343,345,
        3,52,26,0,344,343,1,0,0,0,344,345,1,0,0,0,345,346,1,0,0,0,346,350,
        3,56,28,0,347,350,3,52,26,0,348,350,3,54,27,0,349,344,1,0,0,0,349,
        347,1,0,0,0,349,348,1,0,0,0,350,51,1,0,0,0,351,353,5,34,0,0,352,
        354,5,58,0,0,353,352,1,0,0,0,354,355,1,0,0,0,355,356,1,0,0,0,355,
        353,1,0,0,0,356,53,1,0,0,0,357,358,5,35,0,0,358,359,5,37,0,0,359,
        360,7,2,0,0,360,361,5,38,0,0,361,362,7,2,0,0,362,55,1,0,0,0,363,
        364,5,36,0,0,364,366,5,52,0,0,365,367,3,58,29,0,366,365,1,0,0,0,
        367,368,1,0,0,0,368,369,1,0,0,0,368,366,1,0,0,0,369,57,1,0,0,0,370,
        371,3,60,30,0,371,372,3,64,32,0,372,59,1,0,0,0,373,374,5,58,0,0,
        374,375,7,2,0,0,375,377,7,2,0,0,376,378,5,52,0,0,377,376,1,0,0,0,
        377,378,1,0,0,0,378,380,1,0,0,0,379,381,5,1,0,0,380,379,1,0,0,0,
        380,381,1,0,0,0,381,61,1,0,0,0,382,383,7,2,0,0,383,384,5,11,0,0,
        384,385,7,2,0,0,385,63,1,0,0,0,386,387,5,49,0,0,387,392,3,62,31,
        0,388,389,7,3,0,0,389,391,3,62,31,0,390,388,1,0,0,0,391,394,1,0,
        0,0,392,393,1,0,0,0,392,390,1,0,0,0,393,396,1,0,0,0,394,392,1,0,
        0,0,395,397,7,3,0,0,396,395,1,0,0,0,396,397,1,0,0,0,397,398,1,0,
        0,0,398,399,5,50,0,0,399,65,1,0,0,0,400,401,5,20,0,0,401,402,7,1,
        0,0,402,404,3,68,34,0,403,405,3,8,4,0,404,403,1,0,0,0,404,405,1,
        0,0,0,405,67,1,0,0,0,406,410,3,70,35,0,407,410,3,72,36,0,408,410,
        3,74,37,0,409,406,1,0,0,0,409,407,1,0,0,0,409,408,1,0,0,0,410,69,
        1,0,0,0,411,412,5,21,0,0,412,414,7,7,0,0,413,415,5,23,0,0,414,413,
        1,0,0,0,414,415,1,0,0,0,415,416,1,0,0,0,416,417,5,30,0,0,417,418,
        5,33,0,0,418,419,5,25,0,0,419,421,3,34,17,0,420,422,3,8,4,0,421,
        420,1,0,0,0,421,422,1,0,0,0,422,71,1,0,0,0,423,424,5,21,0,0,424,
        426,7,8,0,0,425,427,5,23,0,0,426,425,1,0,0,0,426,427,1,0,0,0,427,
        428,1,0,0,0,428,429,5,31,0,0,429,430,5,33,0,0,430,431,5,25,0,0,431,
        432,3,34,17,0,432,433,5,32,0,0,433,434,5,33,0,0,434,435,5,25,0,0,
        435,437,3,34,17,0,436,438,3,8,4,0,437,436,1,0,0,0,437,438,1,0,0,
        0,438,73,1,0,0,0,439,440,5,21,0,0,440,442,7,1,0,0,441,439,1,0,0,
        0,441,442,1,0,0,0,442,443,1,0,0,0,443,444,3,76,38,0,444,75,1,0,0,
        0,445,447,5,23,0,0,446,445,1,0,0,0,446,447,1,0,0,0,447,449,1,0,0,
        0,448,450,3,78,39,0,449,448,1,0,0,0,450,451,1,0,0,0,451,452,1,0,
        0,0,451,449,1,0,0,0,452,77,1,0,0,0,453,454,5,22,0,0,454,455,7,1,
        0,0,455,456,5,19,0,0,456,459,7,1,0,0,457,458,5,25,0,0,458,460,3,
        46,23,0,459,457,1,0,0,0,459,460,1,0,0,0,460,462,1,0,0,0,461,463,
        3,8,4,0,462,461,1,0,0,0,462,463,1,0,0,0,463,79,1,0,0,0,55,87,93,
        99,106,115,122,124,131,134,140,149,166,174,181,188,195,207,210,217,
        224,231,238,240,242,270,277,284,291,298,300,302,315,320,328,333,
        341,344,349,355,368,377,380,392,396,404,409,414,421,426,437,441,
        446,451,459,462
    ]

class at_krlParser ( Parser ):

    grammarFileName = "at_krl.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'='", "':='", "'<-'", "'->'", "';'", 
                     "','", "'-'", "'~'", "'!'", "'not'", "'|'", "'\\r\\n'", 
                     "'\\u0423\\u0412\\u0415\\u0420\\u0415\\u041D\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u0422\\u041E\\u0427\\u041D\\u041E\\u0421\\u0422\\u042C'", 
                     "'\\u041F\\u0420\\u0410\\u0412\\u0418\\u041B\\u041E'", 
                     "'\\u0415\\u0421\\u041B\\u0418'", "'\\u0422\\u041E'", 
                     "'\\u0418\\u041D\\u0410\\u0427\\u0415'", "'\\u0422\\u0418\\u041F'", 
                     "'\\u041E\\u0411\\u042A\\u0415\\u041A\\u0422'", "'\\u0413\\u0420\\u0423\\u041F\\u041F\\u0410'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422\\u042B'", 
                     "'\\u041A\\u041E\\u041C\\u041C\\u0415\\u041D\\u0422\\u0410\\u0420\\u0418\\u0419'", 
                     "'\\u0417\\u041D\\u0410\\u0427\\u0415\\u041D\\u0418\\u0415'", 
                     "'\\u0418\\u041D\\u0422\\u0415\\u0420\\u0412\\u0410\\u041B'", 
                     "'\\u0418\\u043D\\u0442\\u0435\\u0440\\u0432\\u0430\\u043B'", 
                     "'\\u0421\\u041E\\u0411\\u042B\\u0422\\u0418\\u0415'", 
                     "'\\u0421\\u043E\\u0431\\u044B\\u0442\\u0438\\u0435'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u0412\\u043E\\u0437\\u043D'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041D\\u0430\\u0447'", 
                     "'\\u0410\\u0422\\u0420\\u0418\\u0411\\u0423\\u0422 \\u0423\\u0441\\u043B\\u041E\\u043A\\u043E\\u043D\\u0447'", 
                     "'\\u0422\\u0418\\u041F \\u041B\\u043E\\u0433\\u0412\\u044B\\u0440'", 
                     "'\\u0421\\u0418\\u041C\\u0412\\u041E\\u041B'", "'\\u0427\\u0418\\u0421\\u041B\\u041E'", 
                     "'\\u041D\\u0415\\u0427\\u0415\\u0422\\u041A\\u0418\\u0419'", 
                     "'\\u041E\\u0422'", "'\\u0414\\u041E'", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                     "'.'", "'('", "')'", "'['", "']'", "'{'", "'}'" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "NEW_LINE", "BELIEF", "ACCURACY", "RULE", "IF", "THEN", 
                      "ELSE", "TYPE", "OBJECT", "GROUP", "ATTR", "ATTRS", 
                      "COMMENT", "VALUE", "INTERVAL", "CASED_INTERVAL", 
                      "EVENT", "CASED_EVENT", "OCCURANCE_CONDITION", "OPEN", 
                      "CLOSE", "SIMPLE_EXP_TYPE", "SYM", "NUM", "FUZ", "FROM", 
                      "TO", "LOG_SIGN", "COMP_SIGN", "LOWP_MATH_SIGN", "HIGHP_MATH_SIGN", 
                      "ALLEN_SIGN", "DOT", "L_BR", "R_BR", "LS_BR", "RS_BR", 
                      "LF_BR", "RF_BR", "LETTER", "NUMERIC", "ALPHANUMERIC", 
                      "ALPHANUMERIC_U", "FRAC", "WS", "COMM_CHAR", "STRING" ]

    RULE_knowledge_base = 0
    RULE_kb_types = 1
    RULE_kb_classes = 2
    RULE_kb_rules = 3
    RULE_commentary = 4
    RULE_instructions = 5
    RULE_assign_instruction = 6
    RULE_kb_rule = 7
    RULE_kb_rule_instructions = 8
    RULE_kb_rule_condition = 9
    RULE_kb_rule_else_instructions = 10
    RULE_belief = 11
    RULE_accuracy = 12
    RULE_non_factor = 13
    RULE_kb_operation = 14
    RULE_kb_allen_operation = 15
    RULE_simple_operation = 16
    RULE_simple_evaluatable = 17
    RULE_simple_value = 18
    RULE_kb_value = 19
    RULE_ref_path = 20
    RULE_simple_ref = 21
    RULE_kb_reference = 22
    RULE_evaluatable = 23
    RULE_kb_type = 24
    RULE_kb_type_body = 25
    RULE_symbolic_type_body = 26
    RULE_numeric_type_body = 27
    RULE_fuzzy_type_body = 28
    RULE_membersip_function = 29
    RULE_mf_def = 30
    RULE_mf_point = 31
    RULE_mf_body = 32
    RULE_kb_class = 33
    RULE_kb_class_body = 34
    RULE_event_body = 35
    RULE_interval_body = 36
    RULE_object_body = 37
    RULE_attributes = 38
    RULE_attribute = 39

    ruleNames =  [ "knowledge_base", "kb_types", "kb_classes", "kb_rules", 
                   "commentary", "instructions", "assign_instruction", "kb_rule", 
                   "kb_rule_instructions", "kb_rule_condition", "kb_rule_else_instructions", 
                   "belief", "accuracy", "non_factor", "kb_operation", "kb_allen_operation", 
                   "simple_operation", "simple_evaluatable", "simple_value", 
                   "kb_value", "ref_path", "simple_ref", "kb_reference", 
                   "evaluatable", "kb_type", "kb_type_body", "symbolic_type_body", 
                   "numeric_type_body", "fuzzy_type_body", "membersip_function", 
                   "mf_def", "mf_point", "mf_body", "kb_class", "kb_class_body", 
                   "event_body", "interval_body", "object_body", "attributes", 
                   "attribute" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    NEW_LINE=12
    BELIEF=13
    ACCURACY=14
    RULE=15
    IF=16
    THEN=17
    ELSE=18
    TYPE=19
    OBJECT=20
    GROUP=21
    ATTR=22
    ATTRS=23
    COMMENT=24
    VALUE=25
    INTERVAL=26
    CASED_INTERVAL=27
    EVENT=28
    CASED_EVENT=29
    OCCURANCE_CONDITION=30
    OPEN=31
    CLOSE=32
    SIMPLE_EXP_TYPE=33
    SYM=34
    NUM=35
    FUZ=36
    FROM=37
    TO=38
    LOG_SIGN=39
    COMP_SIGN=40
    LOWP_MATH_SIGN=41
    HIGHP_MATH_SIGN=42
    ALLEN_SIGN=43
    DOT=44
    L_BR=45
    R_BR=46
    LS_BR=47
    RS_BR=48
    LF_BR=49
    RF_BR=50
    LETTER=51
    NUMERIC=52
    ALPHANUMERIC=53
    ALPHANUMERIC_U=54
    FRAC=55
    WS=56
    COMM_CHAR=57
    STRING=58

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.0")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class Knowledge_baseContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_types(self):
            return self.getTypedRuleContext(at_krlParser.Kb_typesContext,0)


        def kb_classes(self):
            return self.getTypedRuleContext(at_krlParser.Kb_classesContext,0)


        def kb_rules(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rulesContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_knowledge_base

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKnowledge_base" ):
                listener.enterKnowledge_base(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKnowledge_base" ):
                listener.exitKnowledge_base(self)




    def knowledge_base(self):

        localctx = at_krlParser.Knowledge_baseContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_knowledge_base)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self.kb_types()
            self.state = 81
            self.kb_classes()
            self.state = 82
            self.kb_rules()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_type(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_typeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_typeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_types

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_types" ):
                listener.enterKb_types(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_types" ):
                listener.exitKb_types(self)




    def kb_types(self):

        localctx = at_krlParser.Kb_typesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_kb_types)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,0,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 84
                    self.kb_type() 
                self.state = 89
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_class(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_classContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_classContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_classes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_classes" ):
                listener.enterKb_classes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_classes" ):
                listener.exitKb_classes(self)




    def kb_classes(self):

        localctx = at_krlParser.Kb_classesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_kb_classes)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 93
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,1,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 90
                    self.kb_class() 
                self.state = 95
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,1,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rulesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_rule(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_ruleContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_ruleContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rules

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rules" ):
                listener.enterKb_rules(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rules" ):
                listener.exitKb_rules(self)




    def kb_rules(self):

        localctx = at_krlParser.Kb_rulesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_kb_rules)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 99
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,2,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 96
                    self.kb_rule() 
                self.state = 101
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,2,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class CommentaryContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def COMMENT(self):
            return self.getToken(at_krlParser.COMMENT, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_commentary

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCommentary" ):
                listener.enterCommentary(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCommentary" ):
                listener.exitCommentary(self)




    def commentary(self):

        localctx = at_krlParser.CommentaryContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_commentary)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 102
            self.match(at_krlParser.COMMENT)
            self.state = 104 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 103
                    self.matchWildcard()

                else:
                    raise NoViableAltException(self)
                self.state = 106 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,3,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def assign_instruction(self):
            return self.getTypedRuleContext(at_krlParser.Assign_instructionContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstructions" ):
                listener.enterInstructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstructions" ):
                listener.exitInstructions(self)




    def instructions(self):

        localctx = at_krlParser.InstructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_instructions)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 108
            self.assign_instruction()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Assign_instructionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_assign_instruction

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign_instruction" ):
                listener.enterAssign_instruction(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign_instruction" ):
                listener.exitAssign_instruction(self)




    def assign_instruction(self):

        localctx = at_krlParser.Assign_instructionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_assign_instruction)
        self._la = 0 # Token type
        try:
            self.state = 124
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 110
                self.ref_path()
                self.state = 111
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 14) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 112
                self.evaluatable()
                self.state = 115
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 113
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 10, 15, 18, 24, 45, 52, 53, 54, 55, 58]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 117
                self.evaluatable()
                self.state = 118
                self.match(at_krlParser.T__3)
                self.state = 119
                self.ref_path()
                self.state = 122
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 120
                    self.non_factor()
                    pass
                elif token in [-1, 7, 8, 9, 10, 15, 18, 24, 45, 52, 53, 54, 55, 58]:
                    pass
                else:
                    raise NoViableAltException(self)

                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_ruleContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RULE(self):
            return self.getToken(at_krlParser.RULE, 0)

        def kb_rule_condition(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_conditionContext,0)


        def kb_rule_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_instructionsContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def kb_rule_else_instructions(self):
            return self.getTypedRuleContext(at_krlParser.Kb_rule_else_instructionsContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule" ):
                listener.enterKb_rule(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule" ):
                listener.exitKb_rule(self)




    def kb_rule(self):

        localctx = at_krlParser.Kb_ruleContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_kb_rule)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(at_krlParser.RULE)
            self.state = 127
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 128
            self.kb_rule_condition()
            self.state = 129
            self.kb_rule_instructions()
            self.state = 131
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==18:
                self.state = 130
                self.kb_rule_else_instructions()


            self.state = 134
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 133
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def THEN(self):
            return self.getToken(at_krlParser.THEN, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_instructions" ):
                listener.enterKb_rule_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_instructions" ):
                listener.exitKb_rule_instructions(self)




    def kb_rule_instructions(self):

        localctx = at_krlParser.Kb_rule_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_kb_rule_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            self.match(at_krlParser.THEN)
            self.state = 138 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 137
                self.instructions()
                self.state = 140 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 355819554934359936) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_conditionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self):
            return self.getToken(at_krlParser.IF, 0)

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_condition

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_condition" ):
                listener.enterKb_rule_condition(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_condition" ):
                listener.exitKb_rule_condition(self)




    def kb_rule_condition(self):

        localctx = at_krlParser.Kb_rule_conditionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_kb_rule_condition)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 142
            self.match(at_krlParser.IF)
            self.state = 143
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_rule_else_instructionsContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ELSE(self):
            return self.getToken(at_krlParser.ELSE, 0)

        def instructions(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.InstructionsContext)
            else:
                return self.getTypedRuleContext(at_krlParser.InstructionsContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_rule_else_instructions

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_rule_else_instructions" ):
                listener.enterKb_rule_else_instructions(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_rule_else_instructions" ):
                listener.exitKb_rule_else_instructions(self)




    def kb_rule_else_instructions(self):

        localctx = at_krlParser.Kb_rule_else_instructionsContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_kb_rule_else_instructions)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 145
            self.match(at_krlParser.ELSE)
            self.state = 147 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 146
                self.instructions()
                self.state = 149 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 355819554934359936) != 0)):
                    break

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BeliefContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def BELIEF(self):
            return self.getToken(at_krlParser.BELIEF, 0)

        def LS_BR(self):
            return self.getToken(at_krlParser.LS_BR, 0)

        def RS_BR(self):
            return self.getToken(at_krlParser.RS_BR, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_belief

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBelief" ):
                listener.enterBelief(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBelief" ):
                listener.exitBelief(self)




    def belief(self):

        localctx = at_krlParser.BeliefContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_belief)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 151
            self.match(at_krlParser.BELIEF)
            self.state = 152
            self.match(at_krlParser.LS_BR)
            self.state = 153
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 154
            _la = self._input.LA(1)
            if not(_la==5 or _la==6):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 155
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 156
            self.match(at_krlParser.RS_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AccuracyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ACCURACY(self):
            return self.getToken(at_krlParser.ACCURACY, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_accuracy

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAccuracy" ):
                listener.enterAccuracy(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAccuracy" ):
                listener.exitAccuracy(self)




    def accuracy(self):

        localctx = at_krlParser.AccuracyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_accuracy)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 158
            self.match(at_krlParser.ACCURACY)
            self.state = 159
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Non_factorContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def belief(self):
            return self.getTypedRuleContext(at_krlParser.BeliefContext,0)


        def accuracy(self):
            return self.getTypedRuleContext(at_krlParser.AccuracyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_non_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNon_factor" ):
                listener.enterNon_factor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNon_factor" ):
                listener.exitNon_factor(self)




    def non_factor(self):

        localctx = at_krlParser.Non_factorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_non_factor)
        try:
            self.state = 166
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,11,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 161
                self.belief()
                self.state = 162
                self.accuracy()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 164
                self.belief()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 165
                self.accuracy()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def kb_value(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_valueContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_valueContext,i)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def kb_reference(self):
            return self.getTypedRuleContext(at_krlParser.Kb_referenceContext,0)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Kb_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Kb_operationContext,i)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def kb_allen_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_allen_operationContext,0)


        def HIGHP_MATH_SIGN(self):
            return self.getToken(at_krlParser.HIGHP_MATH_SIGN, 0)

        def LOWP_MATH_SIGN(self):
            return self.getToken(at_krlParser.LOWP_MATH_SIGN, 0)

        def COMP_SIGN(self):
            return self.getToken(at_krlParser.COMP_SIGN, 0)

        def LOG_SIGN(self):
            return self.getToken(at_krlParser.LOG_SIGN, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_kb_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_operation" ):
                listener.enterKb_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_operation" ):
                listener.exitKb_operation(self)



    def kb_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Kb_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 28
        self.enterRecursionRule(localctx, 28, self.RULE_kb_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 210
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,17,self._ctx)
            if la_ == 1:
                self.state = 169
                self.ref_path()
                self.state = 170
                self.match(at_krlParser.T__0)
                self.state = 171
                self.kb_value()
                self.state = 174
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,12,self._ctx)
                if la_ == 1:
                    self.state = 172
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 2:
                self.state = 176
                self.kb_value()
                self.state = 177
                self.match(at_krlParser.T__0)
                self.state = 178
                self.ref_path()
                self.state = 181
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
                if la_ == 1:
                    self.state = 179
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 3:
                self.state = 183
                self.ref_path()
                self.state = 184
                self.match(at_krlParser.T__0)
                self.state = 185
                self.ref_path()
                self.state = 188
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,14,self._ctx)
                if la_ == 1:
                    self.state = 186
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 4:
                self.state = 190
                self.kb_value()
                self.state = 191
                self.match(at_krlParser.T__0)
                self.state = 192
                self.kb_value()
                self.state = 195
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,15,self._ctx)
                if la_ == 1:
                    self.state = 193
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 5:
                self.state = 197
                self.kb_reference()
                pass

            elif la_ == 6:
                self.state = 198
                self.kb_value()
                pass

            elif la_ == 7:
                self.state = 199
                self.match(at_krlParser.L_BR)
                self.state = 200
                self.kb_operation(0)
                self.state = 201
                self.match(at_krlParser.R_BR)
                pass

            elif la_ == 8:
                self.state = 203
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1920) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 204
                self.kb_operation(0)
                self.state = 207
                self._errHandler.sync(self)
                la_ = self._interp.adaptivePredict(self._input,16,self._ctx)
                if la_ == 1:
                    self.state = 205
                    self.non_factor()
                    pass

                elif la_ == 2:
                    pass


                pass

            elif la_ == 9:
                self.state = 209
                self.kb_allen_operation()
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 242
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,23,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 240
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,22,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 212
                        if not self.precpred(self._ctx, 7):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 7)")
                        self.state = 213
                        self.match(at_krlParser.HIGHP_MATH_SIGN)
                        self.state = 214
                        self.kb_operation(0)
                        self.state = 217
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,18,self._ctx)
                        if la_ == 1:
                            self.state = 215
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 219
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 220
                        self.match(at_krlParser.LOWP_MATH_SIGN)
                        self.state = 221
                        self.kb_operation(0)
                        self.state = 224
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,19,self._ctx)
                        if la_ == 1:
                            self.state = 222
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 226
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 227
                        self.match(at_krlParser.COMP_SIGN)
                        self.state = 228
                        self.kb_operation(0)
                        self.state = 231
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
                        if la_ == 1:
                            self.state = 229
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Kb_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_kb_operation)
                        self.state = 233
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 234
                        self.match(at_krlParser.LOG_SIGN)
                        self.state = 235
                        self.kb_operation(0)
                        self.state = 238
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,21,self._ctx)
                        if la_ == 1:
                            self.state = 236
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 244
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,23,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Kb_allen_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALLEN_SIGN(self):
            return self.getToken(at_krlParser.ALLEN_SIGN, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_kb_allen_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_allen_operation" ):
                listener.enterKb_allen_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_allen_operation" ):
                listener.exitKb_allen_operation(self)




    def kb_allen_operation(self):

        localctx = at_krlParser.Kb_allen_operationContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_kb_allen_operation)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 245
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 246
            self.match(at_krlParser.ALLEN_SIGN)
            self.state = 247
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_operationContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def ref_path(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Ref_pathContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Ref_pathContext,i)


        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def simple_operation(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_operationContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_operationContext,i)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def HIGHP_MATH_SIGN(self):
            return self.getToken(at_krlParser.HIGHP_MATH_SIGN, 0)

        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def LOWP_MATH_SIGN(self):
            return self.getToken(at_krlParser.LOWP_MATH_SIGN, 0)

        def COMP_SIGN(self):
            return self.getToken(at_krlParser.COMP_SIGN, 0)

        def LOG_SIGN(self):
            return self.getToken(at_krlParser.LOG_SIGN, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_simple_operation

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_operation" ):
                listener.enterSimple_operation(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_operation" ):
                listener.exitSimple_operation(self)



    def simple_operation(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = at_krlParser.Simple_operationContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 32
        self.enterRecursionRule(localctx, 32, self.RULE_simple_operation, _p)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 270
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,24,self._ctx)
            if la_ == 1:
                self.state = 250
                self.simple_value()
                self.state = 251
                self.match(at_krlParser.T__0)
                self.state = 252
                self.ref_path()
                pass

            elif la_ == 2:
                self.state = 254
                self.ref_path()
                self.state = 255
                self.match(at_krlParser.T__0)
                self.state = 256
                self.ref_path()
                pass

            elif la_ == 3:
                self.state = 258
                self.ref_path()
                self.state = 259
                self.match(at_krlParser.T__0)
                self.state = 260
                self.simple_value()
                pass

            elif la_ == 4:
                self.state = 262
                self.simple_ref()
                pass

            elif la_ == 5:
                self.state = 263
                self.simple_value()
                pass

            elif la_ == 6:
                self.state = 264
                self.match(at_krlParser.L_BR)
                self.state = 265
                self.simple_operation(0)
                self.state = 266
                self.match(at_krlParser.R_BR)
                pass

            elif la_ == 7:
                self.state = 268
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 1792) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 269
                self.simple_operation(1)
                pass


            self._ctx.stop = self._input.LT(-1)
            self.state = 302
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,30,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 300
                    self._errHandler.sync(self)
                    la_ = self._interp.adaptivePredict(self._input,29,self._ctx)
                    if la_ == 1:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 272
                        if not self.precpred(self._ctx, 6):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 6)")
                        self.state = 273
                        self.match(at_krlParser.HIGHP_MATH_SIGN)
                        self.state = 274
                        self.simple_operation(0)
                        self.state = 277
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,25,self._ctx)
                        if la_ == 1:
                            self.state = 275
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 2:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 279
                        if not self.precpred(self._ctx, 5):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 5)")
                        self.state = 280
                        self.match(at_krlParser.LOWP_MATH_SIGN)
                        self.state = 281
                        self.simple_operation(0)
                        self.state = 284
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,26,self._ctx)
                        if la_ == 1:
                            self.state = 282
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 3:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 286
                        if not self.precpred(self._ctx, 4):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 4)")
                        self.state = 287
                        self.match(at_krlParser.COMP_SIGN)
                        self.state = 288
                        self.simple_operation(0)
                        self.state = 291
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,27,self._ctx)
                        if la_ == 1:
                            self.state = 289
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

                    elif la_ == 4:
                        localctx = at_krlParser.Simple_operationContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_simple_operation)
                        self.state = 293
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 294
                        self.match(at_krlParser.LOG_SIGN)
                        self.state = 295
                        self.simple_operation(0)
                        self.state = 298
                        self._errHandler.sync(self)
                        la_ = self._interp.adaptivePredict(self._input,28,self._ctx)
                        if la_ == 1:
                            self.state = 296
                            self.non_factor()
                            pass

                        elif la_ == 2:
                            pass


                        pass

             
                self.state = 304
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,30,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx


    class Simple_evaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def simple_operation(self):
            return self.getTypedRuleContext(at_krlParser.Simple_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_evaluatable" ):
                listener.enterSimple_evaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_evaluatable" ):
                listener.exitSimple_evaluatable(self)




    def simple_evaluatable(self):

        localctx = at_krlParser.Simple_evaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_simple_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 305
            self.simple_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def FRAC(self):
            return self.getToken(at_krlParser.FRAC, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_simple_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_value" ):
                listener.enterSimple_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_value" ):
                listener.exitSimple_value(self)




    def simple_value(self):

        localctx = at_krlParser.Simple_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_simple_value)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 307
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 328762772798046208) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_valueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def kb_value(self):
            return self.getTypedRuleContext(at_krlParser.Kb_valueContext,0)


        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def simple_value(self):
            return self.getTypedRuleContext(at_krlParser.Simple_valueContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_value

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_value" ):
                listener.enterKb_value(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_value" ):
                listener.exitKb_value(self)




    def kb_value(self):

        localctx = at_krlParser.Kb_valueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_kb_value)
        try:
            self.state = 315
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 309
                self.match(at_krlParser.L_BR)
                self.state = 310
                self.kb_value()
                self.state = 311
                self.non_factor()
                self.state = 312
                self.match(at_krlParser.R_BR)
                pass
            elif token in [52, 55, 58]:
                self.enterOuterAlt(localctx, 2)
                self.state = 314
                self.simple_value()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Ref_pathContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def DOT(self):
            return self.getToken(at_krlParser.DOT, 0)

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_ref_path

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRef_path" ):
                listener.enterRef_path(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRef_path" ):
                listener.exitRef_path(self)




    def ref_path(self):

        localctx = at_krlParser.Ref_pathContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_ref_path)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 317
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 320
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,32,self._ctx)
            if la_ == 1:
                self.state = 318
                self.match(at_krlParser.DOT)
                self.state = 319
                self.ref_path()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Simple_refContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ref_path(self):
            return self.getTypedRuleContext(at_krlParser.Ref_pathContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_simple_ref

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSimple_ref" ):
                listener.enterSimple_ref(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSimple_ref" ):
                listener.exitSimple_ref(self)




    def simple_ref(self):

        localctx = at_krlParser.Simple_refContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_simple_ref)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 322
            self.ref_path()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_referenceContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def L_BR(self):
            return self.getToken(at_krlParser.L_BR, 0)

        def simple_ref(self):
            return self.getTypedRuleContext(at_krlParser.Simple_refContext,0)


        def R_BR(self):
            return self.getToken(at_krlParser.R_BR, 0)

        def non_factor(self):
            return self.getTypedRuleContext(at_krlParser.Non_factorContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_reference

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_reference" ):
                listener.enterKb_reference(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_reference" ):
                listener.exitKb_reference(self)




    def kb_reference(self):

        localctx = at_krlParser.Kb_referenceContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_kb_reference)
        try:
            self.state = 333
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [45]:
                self.enterOuterAlt(localctx, 1)
                self.state = 324
                self.match(at_krlParser.L_BR)
                self.state = 325
                self.simple_ref()
                self.state = 328
                self._errHandler.sync(self)
                token = self._input.LA(1)
                if token in [13, 14]:
                    self.state = 326
                    self.non_factor()
                    pass
                elif token in [46]:
                    pass
                else:
                    raise NoViableAltException(self)

                self.state = 330
                self.match(at_krlParser.R_BR)
                pass
            elif token in [53, 54]:
                self.enterOuterAlt(localctx, 2)
                self.state = 332
                self.simple_ref()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class EvaluatableContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def kb_operation(self):
            return self.getTypedRuleContext(at_krlParser.Kb_operationContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_evaluatable

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvaluatable" ):
                listener.enterEvaluatable(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvaluatable" ):
                listener.exitEvaluatable(self)




    def evaluatable(self):

        localctx = at_krlParser.EvaluatableContext(self, self._ctx, self.state)
        self.enterRule(localctx, 46, self.RULE_evaluatable)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 335
            self.kb_operation(0)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_typeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def kb_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_type_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type" ):
                listener.enterKb_type(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type" ):
                listener.exitKb_type(self)




    def kb_type(self):

        localctx = at_krlParser.Kb_typeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 48, self.RULE_kb_type)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 337
            self.match(at_krlParser.TYPE)
            self.state = 338
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 339
            self.kb_type_body()
            self.state = 341
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 340
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def fuzzy_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Fuzzy_type_bodyContext,0)


        def symbolic_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Symbolic_type_bodyContext,0)


        def numeric_type_body(self):
            return self.getTypedRuleContext(at_krlParser.Numeric_type_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_type_body" ):
                listener.enterKb_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_type_body" ):
                listener.exitKb_type_body(self)




    def kb_type_body(self):

        localctx = at_krlParser.Kb_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 50, self.RULE_kb_type_body)
        self._la = 0 # Token type
        try:
            self.state = 349
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,37,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 344
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if _la==34:
                    self.state = 343
                    self.symbolic_type_body()


                self.state = 346
                self.fuzzy_type_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 347
                self.symbolic_type_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 348
                self.numeric_type_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Symbolic_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def SYM(self):
            return self.getToken(at_krlParser.SYM, 0)

        def STRING(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.STRING)
            else:
                return self.getToken(at_krlParser.STRING, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_symbolic_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSymbolic_type_body" ):
                listener.enterSymbolic_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSymbolic_type_body" ):
                listener.exitSymbolic_type_body(self)




    def symbolic_type_body(self):

        localctx = at_krlParser.Symbolic_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 52, self.RULE_symbolic_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 351
            self.match(at_krlParser.SYM)
            self.state = 353 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 352
                    self.match(at_krlParser.STRING)

                else:
                    raise NoViableAltException(self)
                self.state = 355 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,38,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Numeric_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUM(self):
            return self.getToken(at_krlParser.NUM, 0)

        def FROM(self):
            return self.getToken(at_krlParser.FROM, 0)

        def TO(self):
            return self.getToken(at_krlParser.TO, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_numeric_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumeric_type_body" ):
                listener.enterNumeric_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumeric_type_body" ):
                listener.exitNumeric_type_body(self)




    def numeric_type_body(self):

        localctx = at_krlParser.Numeric_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 54, self.RULE_numeric_type_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 357
            self.match(at_krlParser.NUM)
            self.state = 358
            self.match(at_krlParser.FROM)
            self.state = 359
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 360
            self.match(at_krlParser.TO)
            self.state = 361
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Fuzzy_type_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FUZ(self):
            return self.getToken(at_krlParser.FUZ, 0)

        def NUMERIC(self):
            return self.getToken(at_krlParser.NUMERIC, 0)

        def membersip_function(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Membersip_functionContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Membersip_functionContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_fuzzy_type_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuzzy_type_body" ):
                listener.enterFuzzy_type_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuzzy_type_body" ):
                listener.exitFuzzy_type_body(self)




    def fuzzy_type_body(self):

        localctx = at_krlParser.Fuzzy_type_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 56, self.RULE_fuzzy_type_body)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 363
            self.match(at_krlParser.FUZ)
            self.state = 364
            self.match(at_krlParser.NUMERIC)
            self.state = 366 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 365
                    self.membersip_function()

                else:
                    raise NoViableAltException(self)
                self.state = 368 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,39,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Membersip_functionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mf_def(self):
            return self.getTypedRuleContext(at_krlParser.Mf_defContext,0)


        def mf_body(self):
            return self.getTypedRuleContext(at_krlParser.Mf_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_membersip_function

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMembersip_function" ):
                listener.enterMembersip_function(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMembersip_function" ):
                listener.exitMembersip_function(self)




    def membersip_function(self):

        localctx = at_krlParser.Membersip_functionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 58, self.RULE_membersip_function)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 370
            self.mf_def()
            self.state = 371
            self.mf_body()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_defContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def STRING(self):
            return self.getToken(at_krlParser.STRING, 0)

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_def

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_def" ):
                listener.enterMf_def(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_def" ):
                listener.exitMf_def(self)




    def mf_def(self):

        localctx = at_krlParser.Mf_defContext(self, self._ctx, self.state)
        self.enterRule(localctx, 60, self.RULE_mf_def)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 373
            self.match(at_krlParser.STRING)
            self.state = 374
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 375
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 377
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==52:
                self.state = 376
                self.match(at_krlParser.NUMERIC)


            self.state = 380
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==1:
                self.state = 379
                self.match(at_krlParser.T__0)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_pointContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def NUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.NUMERIC)
            else:
                return self.getToken(at_krlParser.NUMERIC, i)

        def FRAC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.FRAC)
            else:
                return self.getToken(at_krlParser.FRAC, i)

        def getRuleIndex(self):
            return at_krlParser.RULE_mf_point

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_point" ):
                listener.enterMf_point(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_point" ):
                listener.exitMf_point(self)




    def mf_point(self):

        localctx = at_krlParser.Mf_pointContext(self, self._ctx, self.state)
        self.enterRule(localctx, 62, self.RULE_mf_point)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 382
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 383
            self.match(at_krlParser.T__10)
            self.state = 384
            _la = self._input.LA(1)
            if not(_la==52 or _la==55):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Mf_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LF_BR(self):
            return self.getToken(at_krlParser.LF_BR, 0)

        def RF_BR(self):
            return self.getToken(at_krlParser.RF_BR, 0)

        def mf_point(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Mf_pointContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Mf_pointContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_mf_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMf_body" ):
                listener.enterMf_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMf_body" ):
                listener.exitMf_body(self)




    def mf_body(self):

        localctx = at_krlParser.Mf_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 64, self.RULE_mf_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 386
            self.match(at_krlParser.LF_BR)

            self.state = 387
            self.mf_point()
            self.state = 392
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,42,self._ctx)
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1+1:
                    self.state = 388
                    _la = self._input.LA(1)
                    if not(_la==5 or _la==6):
                        self._errHandler.recoverInline(self)
                    else:
                        self._errHandler.reportMatch(self)
                        self.consume()
                    self.state = 389
                    self.mf_point() 
                self.state = 394
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,42,self._ctx)

            self.state = 396
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==5 or _la==6:
                self.state = 395
                _la = self._input.LA(1)
                if not(_la==5 or _la==6):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 398
            self.match(at_krlParser.RF_BR)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_classContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def OBJECT(self):
            return self.getToken(at_krlParser.OBJECT, 0)

        def kb_class_body(self):
            return self.getTypedRuleContext(at_krlParser.Kb_class_bodyContext,0)


        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class" ):
                listener.enterKb_class(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class" ):
                listener.exitKb_class(self)




    def kb_class(self):

        localctx = at_krlParser.Kb_classContext(self, self._ctx, self.state)
        self.enterRule(localctx, 66, self.RULE_kb_class)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 400
            self.match(at_krlParser.OBJECT)
            self.state = 401
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 402
            self.kb_class_body()
            self.state = 404
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==24:
                self.state = 403
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Kb_class_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def event_body(self):
            return self.getTypedRuleContext(at_krlParser.Event_bodyContext,0)


        def interval_body(self):
            return self.getTypedRuleContext(at_krlParser.Interval_bodyContext,0)


        def object_body(self):
            return self.getTypedRuleContext(at_krlParser.Object_bodyContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_kb_class_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterKb_class_body" ):
                listener.enterKb_class_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitKb_class_body" ):
                listener.exitKb_class_body(self)




    def kb_class_body(self):

        localctx = at_krlParser.Kb_class_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 68, self.RULE_kb_class_body)
        try:
            self.state = 409
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,45,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 406
                self.event_body()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 407
                self.interval_body()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 408
                self.object_body()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Event_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OCCURANCE_CONDITION(self):
            return self.getToken(at_krlParser.OCCURANCE_CONDITION, 0)

        def SIMPLE_EXP_TYPE(self):
            return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, 0)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def simple_evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,0)


        def EVENT(self):
            return self.getToken(at_krlParser.EVENT, 0)

        def CASED_EVENT(self):
            return self.getToken(at_krlParser.CASED_EVENT, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_event_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterEvent_body" ):
                listener.enterEvent_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitEvent_body" ):
                listener.exitEvent_body(self)




    def event_body(self):

        localctx = at_krlParser.Event_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 70, self.RULE_event_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 411
            self.match(at_krlParser.GROUP)
            self.state = 412
            _la = self._input.LA(1)
            if not(_la==28 or _la==29):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 414
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 413
                self.match(at_krlParser.ATTRS)


            self.state = 416
            self.match(at_krlParser.OCCURANCE_CONDITION)
            self.state = 417
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 418
            self.match(at_krlParser.VALUE)
            self.state = 419
            self.simple_evaluatable()
            self.state = 421
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,47,self._ctx)
            if la_ == 1:
                self.state = 420
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Interval_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def OPEN(self):
            return self.getToken(at_krlParser.OPEN, 0)

        def SIMPLE_EXP_TYPE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.SIMPLE_EXP_TYPE)
            else:
                return self.getToken(at_krlParser.SIMPLE_EXP_TYPE, i)

        def VALUE(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.VALUE)
            else:
                return self.getToken(at_krlParser.VALUE, i)

        def simple_evaluatable(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.Simple_evaluatableContext)
            else:
                return self.getTypedRuleContext(at_krlParser.Simple_evaluatableContext,i)


        def CLOSE(self):
            return self.getToken(at_krlParser.CLOSE, 0)

        def INTERVAL(self):
            return self.getToken(at_krlParser.INTERVAL, 0)

        def CASED_INTERVAL(self):
            return self.getToken(at_krlParser.CASED_INTERVAL, 0)

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_interval_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInterval_body" ):
                listener.enterInterval_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInterval_body" ):
                listener.exitInterval_body(self)




    def interval_body(self):

        localctx = at_krlParser.Interval_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 72, self.RULE_interval_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 423
            self.match(at_krlParser.GROUP)
            self.state = 424
            _la = self._input.LA(1)
            if not(_la==26 or _la==27):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 426
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 425
                self.match(at_krlParser.ATTRS)


            self.state = 428
            self.match(at_krlParser.OPEN)
            self.state = 429
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 430
            self.match(at_krlParser.VALUE)
            self.state = 431
            self.simple_evaluatable()
            self.state = 432
            self.match(at_krlParser.CLOSE)
            self.state = 433
            self.match(at_krlParser.SIMPLE_EXP_TYPE)
            self.state = 434
            self.match(at_krlParser.VALUE)
            self.state = 435
            self.simple_evaluatable()
            self.state = 437
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,49,self._ctx)
            if la_ == 1:
                self.state = 436
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Object_bodyContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def attributes(self):
            return self.getTypedRuleContext(at_krlParser.AttributesContext,0)


        def GROUP(self):
            return self.getToken(at_krlParser.GROUP, 0)

        def ALPHANUMERIC(self):
            return self.getToken(at_krlParser.ALPHANUMERIC, 0)

        def ALPHANUMERIC_U(self):
            return self.getToken(at_krlParser.ALPHANUMERIC_U, 0)

        def getRuleIndex(self):
            return at_krlParser.RULE_object_body

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterObject_body" ):
                listener.enterObject_body(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitObject_body" ):
                listener.exitObject_body(self)




    def object_body(self):

        localctx = at_krlParser.Object_bodyContext(self, self._ctx, self.state)
        self.enterRule(localctx, 74, self.RULE_object_body)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 441
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==21:
                self.state = 439
                self.match(at_krlParser.GROUP)
                self.state = 440
                _la = self._input.LA(1)
                if not(_la==53 or _la==54):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()


            self.state = 443
            self.attributes()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributesContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTRS(self):
            return self.getToken(at_krlParser.ATTRS, 0)

        def attribute(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(at_krlParser.AttributeContext)
            else:
                return self.getTypedRuleContext(at_krlParser.AttributeContext,i)


        def getRuleIndex(self):
            return at_krlParser.RULE_attributes

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttributes" ):
                listener.enterAttributes(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttributes" ):
                listener.exitAttributes(self)




    def attributes(self):

        localctx = at_krlParser.AttributesContext(self, self._ctx, self.state)
        self.enterRule(localctx, 76, self.RULE_attributes)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 446
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==23:
                self.state = 445
                self.match(at_krlParser.ATTRS)


            self.state = 449 
            self._errHandler.sync(self)
            _alt = 1+1
            while _alt!=1 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt == 1+1:
                    self.state = 448
                    self.attribute()

                else:
                    raise NoViableAltException(self)
                self.state = 451 
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,52,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AttributeContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def ATTR(self):
            return self.getToken(at_krlParser.ATTR, 0)

        def TYPE(self):
            return self.getToken(at_krlParser.TYPE, 0)

        def ALPHANUMERIC(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC, i)

        def ALPHANUMERIC_U(self, i:int=None):
            if i is None:
                return self.getTokens(at_krlParser.ALPHANUMERIC_U)
            else:
                return self.getToken(at_krlParser.ALPHANUMERIC_U, i)

        def VALUE(self):
            return self.getToken(at_krlParser.VALUE, 0)

        def evaluatable(self):
            return self.getTypedRuleContext(at_krlParser.EvaluatableContext,0)


        def commentary(self):
            return self.getTypedRuleContext(at_krlParser.CommentaryContext,0)


        def getRuleIndex(self):
            return at_krlParser.RULE_attribute

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAttribute" ):
                listener.enterAttribute(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAttribute" ):
                listener.exitAttribute(self)




    def attribute(self):

        localctx = at_krlParser.AttributeContext(self, self._ctx, self.state)
        self.enterRule(localctx, 78, self.RULE_attribute)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 453
            self.match(at_krlParser.ATTR)
            self.state = 454
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 455
            self.match(at_krlParser.TYPE)
            self.state = 456
            _la = self._input.LA(1)
            if not(_la==53 or _la==54):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
            self.state = 459
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==25:
                self.state = 457
                self.match(at_krlParser.VALUE)
                self.state = 458
                self.evaluatable()


            self.state = 462
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,54,self._ctx)
            if la_ == 1:
                self.state = 461
                self.commentary()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[14] = self.kb_operation_sempred
        self._predicates[16] = self.simple_operation_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def kb_operation_sempred(self, localctx:Kb_operationContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 7)
         

            if predIndex == 1:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 3:
                return self.precpred(self._ctx, 4)
         

    def simple_operation_sempred(self, localctx:Simple_operationContext, predIndex:int):
            if predIndex == 4:
                return self.precpred(self._ctx, 6)
         

            if predIndex == 5:
                return self.precpred(self._ctx, 5)
         

            if predIndex == 6:
                return self.precpred(self._ctx, 4)
         

            if predIndex == 7:
                return self.precpred(self._ctx, 3)
         




